//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.jet;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

/**
 * The activator class controls the plug-in life cycle
 */
public class JetPlugin extends AbstractUIPlugin {

	// The plug-in ID
	public static final String PLUGIN_ID = "gov.nasa.jpf.jet"; //$NON-NLS-1$

	// The shared instance
	private static JetPlugin plugin;

	/**
	 * The constructor
	 */
	public JetPlugin() {
		super();
		plugin = this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.eclipse.ui.plugin.AbstractUIPlugin#start(org.osgi.framework.BundleContext
	 * )
	 */
	@Override
	public void start(BundleContext context) throws Exception {
		super.start(context);
		plugin = this;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.eclipse.ui.plugin.AbstractUIPlugin#stop(org.osgi.framework.BundleContext
	 * )
	 */
	@Override
	public void stop(BundleContext context) throws Exception {
		plugin = null;
		super.stop(context);
	}

	/**
	 * Returns the shared instance
	 * 
	 * @return the shared instance
	 */
	public static JetPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns an image descriptor for the image file at the given plug-in
	 * relative path
	 * 
	 * @param path
	 *            the path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(String path) {
		return imageDescriptorFromPlugin(PLUGIN_ID, path);
	}

	/**
	 * Convenience method to log any type of message. The code for this log will
	 * be Status.OK
	 */
	public static void log(int severity, String message, Throwable exception) {
		getDefault().getLog()
				.log(new Status(severity, PLUGIN_ID, IStatus.OK, message,
						exception));
	}

	/**
	 * Convenience method to log plugin information.
	 */
	public static void logInfo(String message) {
		log(IStatus.INFO, message, null);
	}

	/**
	 * Convenience method to log Warnings without an exception This call is
	 * exactly equivalent to logWarning(message, null) @param message the
	 * message to include with the warning
	 */
	public static void logWarning(String message) {
		logWarning(message, null);
	}

	/**
	 * Convenience method to log Warnings along with an exception @param message
	 * the message to include with the warning @param exception the exception to
	 * include with the warning
	 */
	public static void logWarning(String message, Exception exception) {
		log(IStatus.WARNING, message, exception);
	}

	/**
	 * Convenience method to log errors
	 * 
	 * @param message
	 *            the message to display with this error
	 * @param exception
	 *            the exception to associate with ths error.
	 */
	public static void logError(String message, Throwable exception) {
		log(IStatus.ERROR, message, exception);
	}

	/**
	 * Convenience method to log errors
	 * 
	 * @param message
	 *            the message to display with this error
	 */
	public static void logError(String message) {
		logError(message, new Throwable());
	}

}
