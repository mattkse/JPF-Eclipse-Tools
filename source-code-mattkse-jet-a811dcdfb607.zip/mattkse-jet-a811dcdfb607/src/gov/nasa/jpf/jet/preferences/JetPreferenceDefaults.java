//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.jet.preferences;

import java.io.File;

import gov.nasa.jpf.jet.JetPlugin;
import gov.nasa.jpf.jet.ui.prefs.JetPreferencePage;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

public class JetPreferenceDefaults extends AbstractPreferenceInitializer {

	/**
	 * The system dependent default location to find the site.properties file.
	 * The value is defined as &lt;home directory&gt;/.jpf/site.properties
	 */
	public static final String DEFAULT_SITE_PROPERTIES_PATH = getSitePropertiesPath();

	@Override
	public void initializeDefaultPreferences() {
		IPreferenceStore store = JetPlugin.getDefault().getPreferenceStore();
		store.setDefault(JetPreferencePage.SITE_PROPERTIES_PATH,
				DEFAULT_SITE_PROPERTIES_PATH);
	}

	static String getSitePropertiesPath() {
		File userHome = new File(System.getProperty("user.home"));

		File siteDir = new File(userHome, ".jpf");
		if (!siteDir.isDirectory()) {
			File alternateSiteDir = new File(userHome, "jpf");
			if (alternateSiteDir.isDirectory()) {
				siteDir = alternateSiteDir;
			}
		}

		File siteProperties = new File(siteDir, "site.properties");

		return siteProperties.getAbsolutePath();
	}
}
