package gov.nasa.jpf.jet.ui.actions;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.search.IJavaSearchConstants;
import org.eclipse.jdt.core.search.IJavaSearchResultCollector;
import org.eclipse.jdt.core.search.IJavaSearchScope;
import org.eclipse.jdt.core.search.SearchEngine;
import org.eclipse.jdt.internal.core.BinaryType;
import org.eclipse.jdt.ui.JavaUI;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.IEditorActionDelegate;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.texteditor.ITextEditor;

@SuppressWarnings("restriction")
public class JetOpenLibraryAction implements IEditorActionDelegate,
		IWorkbenchWindowActionDelegate {

	public JetOpenLibraryAction() {
	}

	@Override
	public void run(IAction action) {
		try {
			ITextEditor te = (ITextEditor) PlatformUI.getWorkbench()
					.getActiveWorkbenchWindow().getActivePage()
					.getActiveEditor();
			IFileEditorInput fei = (IFileEditorInput) te.getEditorInput();
			IFile file = fei.getFile();
			ICompilationUnit iCompUnit = JavaCore
					.createCompilationUnitFrom(file);
			if (iCompUnit == null) {
				System.out.println("Unable to recognize compilation unit!");
				return;
			}

			IJavaProject proj = iCompUnit.getJavaProject();
			SearchEngine engine = new SearchEngine();
			IJavaSearchScope scope = SearchEngine.createJavaSearchScope(
					new IJavaElement[] { proj },
					IJavaSearchScope.SYSTEM_LIBRARIES);

			IJavaSearchResultCollector resultCollector = new IJavaSearchResultCollector() {

				int numResults = 0;

				@Override
				public void aboutToStart() {
					// do nothing
				}

				@Override
				public void accept(IResource resource, int start, int end,
						IJavaElement enclosingElement, int accuracy)
						throws CoreException {
					if (enclosingElement instanceof BinaryType) {
						JavaUI.openInEditor(enclosingElement);
						numResults++;
						return;
					}
				}

				@Override
				public void done() {
					if (numResults == 0) {
						setStatusLineError();
					}
				}

				@Override
				public IProgressMonitor getProgressMonitor() {
					return null;
				}

			};
			engine.search(ResourcesPlugin.getWorkspace(), iCompUnit
					.getElementName().replace(".java", ""),
					IJavaSearchConstants.TYPE,
					IJavaSearchConstants.DECLARATIONS, scope, resultCollector);
		} catch (Exception e) {
			if (!setStatusLineError()) {
				e.printStackTrace();
			}
		}
	}

	private boolean setStatusLineError() {
		IStatusLineManager statusLineManager = null;
		IWorkbenchPage activePage = PlatformUI.getWorkbench()
				.getActiveWorkbenchWindow().getActivePage();
		if (activePage != null) {
			IWorkbenchPart activePart = activePage.getActivePart();
			if (activePart instanceof IViewPart)
				statusLineManager = ((IViewPart) activePart).getViewSite()
						.getActionBars().getStatusLineManager();
			else if (activePart instanceof IEditorPart)
				statusLineManager = ((IEditorPart) activePart).getEditorSite()
						.getActionBars().getStatusLineManager();
		}
		if (statusLineManager != null) {
			statusLineManager
					.setErrorMessage("JPF: Requested action cannot be performed");
			return true;
		}
		return false;
	}

	@Override
	public void selectionChanged(IAction action, ISelection selection) {
	}

	@Override
	public void dispose() {
	}

	@Override
	public void init(IWorkbenchWindow window) {
	}

	@Override
	public void setActiveEditor(IAction action, IEditorPart targetEditor) {
	}

}
