//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.jet.ui.wizards;

import org.eclipse.core.resources.IProject;
import gov.nasa.jpf.jet.JetPlugin;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.plugin.AbstractUIPlugin;

public class VerifyProjectWizard extends Wizard implements INewWizard {

	private NewVerifyProjectWizardMainPage fMainPage;

	/**
	 * The workbench
	 */
	private IWorkbench fWorkbench;
	/**
	 * The current selection.
	 */
	private IStructuredSelection fSelection;
	
	// cache of newly-created project
	private IProject newProject;

	public VerifyProjectWizard() {
		this(null);
	}

	public VerifyProjectWizard(NewVerifyProjectWizardMainPage mainPage) {
		setDialogSettings(JetPlugin.getDefault().getDialogSettings());

		fMainPage = mainPage;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.fWorkbench = workbench;
		this.fSelection = selection;
		setNeedsProgressMonitor(true);
		setWindowTitle("New JPF Project");
		setDefaultPageImageDescriptor(AbstractUIPlugin.imageDescriptorFromPlugin(
				"gov.nasa.jpf.jet", "icons/wizards/spiral-of-death.png"));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void addPages() {
		if (fMainPage == null)
			fMainPage = new NewVerifyProjectWizardMainPage();
		addPage(fMainPage);
	}

	/**
	 * Returns the workbench which was passed to <code>init</code>.
	 * 
	 * @return the workbench
	 */
	public IWorkbench getWorkbench() {
		return fWorkbench;
	}

	/**
	 * Returns the selection which was passed to <code>init</code>.
	 * 
	 * @return the selection
	 */
	public IStructuredSelection getSelection() {
		return fSelection;
	}

	@Override
	public boolean performFinish() {
		return fMainPage.performFinish();
	}
	
	/**
	 * Creates a new project resource with the selected name.
	 * <p>
	 * In normal usage, this method is invoked after the user has pressed Finish
	 * on the wizard; the enablement of the Finish button implies that all
	 * controls on the pages currently contain valid values.
	 * </p>
	 * <p>
	 * Note that this wizard caches the new project once it has been
	 * successfully created; subsequent invocations of this method will answer
	 * the same project resource without attempting to create it again.
	 * </p>
	 * 
	 * @return the created project resource, or <code>null</code> if the
	 *         project was not created
	 */
//	private IProject createNewProject() {
//		if (newProject != null) {
//			return newProject;
//		}
//
//		// get a project handle
//		final IProject newProjectHandle = fMainPage.getProjectHandle();
//		
//		// get a project descriptor
//		URI location = null;
//		if (!fMainPage.useDefaults()) {
//			location = fMainPage.getLocationURI();
//		}
//		
//		IWorkspace workspace = ResourcesPlugin.getWorkspace();
//		final IProjectDescription description = workspace
//				.newProjectDescription(newProjectHandle.getName());
//		description.setLocationURI(location);
//		
//		// update the referenced project if provided
//		if (referencePage != null) {
//			IProject[] refProjects = referencePage.getReferencedProjects();
//			if (refProjects.length > 0) {
//				description.setReferencedProjects(refProjects);
//			}
//		}
//		
//	}

}
