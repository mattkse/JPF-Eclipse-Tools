//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.jet.ui.prefs;

import gov.nasa.jpf.jet.ui.helpers.prefs.filesystem.JetSiteResourceManager;

import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;

public class JetSiteConfigDialog extends TitleAreaDialog {

	private JetExtensionEditorComposite extensionEditor;
	private String sitePath;

	public JetSiteConfigDialog(Shell parentShell) {
		super(parentShell);
		setShellStyle(getShellStyle() | SWT.RESIZE);
	}

	public void setSitePath(String path) {
		this.sitePath = path;
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		setDialogTitleInfo();

		Composite borders = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		layout.marginHeight = 0;
		layout.marginWidth = 0;
		layout.verticalSpacing = 0;
		borders.setLayout(layout);
		borders.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		// Top bar
		Label barSeparator = new Label(borders, SWT.HORIZONTAL | SWT.SEPARATOR);
		barSeparator
				.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false));

		ScrolledComposite scrolled = new ScrolledComposite(borders,
				SWT.V_SCROLL | SWT.H_SCROLL);

		// always show the focus control
		scrolled.setShowFocusedControl(true);
		scrolled.setExpandHorizontal(true);
		scrolled.setExpandVertical(true);
		// yeah, this is hard-coded
		// major TODO
		scrolled.setMinSize(new Point(700, 500));
		scrolled.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		// Main page
		Composite dialogComp = new Composite(scrolled, SWT.NONE);
		dialogComp.setLayout(new GridLayout());
		dialogComp.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		dialogComp.setFont(parent.getFont());

		createConfigTabFolder(dialogComp);

		scrolled.setContent(dialogComp);

		// Bottom bar
		barSeparator = new Label(borders, SWT.HORIZONTAL | SWT.SEPARATOR);
		barSeparator.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, true,
				false));

		return scrolled;
	}

	private void setDialogTitleInfo() {
		getShell().setText("Configure site.properties");
		setTitle("Configure locations for jpf-core and any other extensions");
		setMessage("Make sure to specify a valid location for jpf-core.  After"
				+ " all items are specified,\nyou will be prompted to create the"
				+ " site.properties file, if it doesn't already exist.");
	}

	private void createConfigTabFolder(Composite parent) {
		extensionEditor = new JetExtensionEditorComposite(parent,
				new JetSiteResourceManager(sitePath));
		extensionEditor.createContents(extensionEditor);
	}

	@Override
	protected void okPressed() {
		if (extensionEditor.saveProperties()) {
			super.okPressed();
		}
	}

	@Override
	protected void cancelPressed() {
		super.cancelPressed();
	}

}
