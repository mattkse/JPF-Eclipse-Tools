//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.jet.ui.helpers.prefs.providers;

import java.util.ArrayList;
import java.util.List;
import gov.nasa.jpf.jet.ui.DirectoryCellEditor;
import gov.nasa.jpf.jet.ui.helpers.prefs.ifaces.JetDuplicateExtChecker;
import gov.nasa.jpf.jet.ui.helpers.prefs.ifaces.JetPropertyChangeListener;
import gov.nasa.jpf.jet.ui.helpers.prefs.models.JPFExtension;
import gov.nasa.jpf.jet.ui.prefs.JetExtensionsTab;

import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ColumnViewer;
import org.eclipse.jface.viewers.EditingSupport;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TextCellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.TableColumn;

public class JPFExtensionEditingSupport extends EditingSupport {

	/**
	 * Hangs onto any listeners that this may have
	 */
	private List<JetPropertyChangeListener> listeners = new ArrayList<JetPropertyChangeListener>(
			3);

	private CellEditor editor;
	private int column;
	private JetDuplicateExtChecker duplicateChecker;

	public JPFExtensionEditingSupport(ColumnViewer viewer, int column,
			List<JetPropertyChangeListener> listeners,
			JetDuplicateExtChecker duplicateChecker) {
		super(viewer);

		// Create the correct editor based on the column index
		switch (column) {
		case JetExtensionsTab.NAME_INDEX:
			editor = new TextCellEditor(((TableViewer) viewer).getTable());
			break;
		case JetExtensionsTab.LOCATION_INDEX:
			editor = new DirectoryCellEditor(((TableViewer) viewer).getTable());
			break;
		default:
			editor = null;
		}
		this.column = column;
		this.listeners = listeners;
		this.duplicateChecker = duplicateChecker;
	}

	@Override
	protected boolean canEdit(Object element) {
		// Don't allow user to change jpf-core text cell editor
		return !(((JPFExtension) element).getName().equals("jpf-core") && !(editor instanceof DirectoryCellEditor));
	}

	@Override
	protected CellEditor getCellEditor(Object element) {
		return editor;
	}

	@Override
	protected Object getValue(Object element) {
		JPFExtension ext = (JPFExtension) element;
		Object ret = null;

		switch (this.column) {
		case JetExtensionsTab.NAME_INDEX:
			ret = ext.getName();
			break;
		case JetExtensionsTab.LOCATION_INDEX:
			ret = ext.getLocation();
			break;
		default:
			break;
		}
		return ret;
	}

	@Override
	protected void setValue(Object element, Object value) {
		JPFExtension ext = (JPFExtension) element;

		switch (this.column) {
		case JetExtensionsTab.NAME_INDEX:
			// Make sure we don't have the same name
			if (!ext.getName().equals(value)) {
				if (duplicateChecker.isDuplicate((String) value)) {
					MessageBox box = new MessageBox(getViewer().getControl()
							.getShell(), SWT.OK | SWT.ERROR);
					box.setText("Name already exists");
					box.setMessage("An extension with that name already exists.");
					box.open();
					return;
				}
				ext.setName(String.valueOf(value));
				break;
			}
			// if nothing has changed, just return and don't update
			return;
		case JetExtensionsTab.LOCATION_INDEX:
			// Make sure we don't have the same location
			if (!ext.getLocation().equals(value)) {
				ext.setLocation(String.valueOf(value));
				break;
			}
			// if nothing has changed, just return and don't update
			return;
		default:
			return;
		}
		fireListeners();
		ColumnViewer viewer = getViewer();
		viewer.update(element, null);
		refresh(viewer);
	}

	private void refresh(ColumnViewer viewer) {
		viewer.refresh();
		repackColumns((TableViewer) viewer);
	}

	private void repackColumns(TableViewer tblViewer) {
		for (TableColumn c : tblViewer.getTable().getColumns()) {
			c.pack();
		}
	}

	public void removeChangeListener(JetPropertyChangeListener listener) {
		listeners.remove(listener);
	}

	private void fireListeners() {
		for (JetPropertyChangeListener listener : listeners)
			listener.changeOccurred();
	}

}
