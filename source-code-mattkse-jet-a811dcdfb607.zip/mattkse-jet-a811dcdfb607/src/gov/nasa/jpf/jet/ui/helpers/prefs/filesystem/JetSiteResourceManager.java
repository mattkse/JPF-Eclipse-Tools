//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.jet.ui.helpers.prefs.filesystem;

import gov.nasa.jpf.jet.JetPlugin;
import gov.nasa.jpf.jet.exceptions.JPFConfigException;
import gov.nasa.jpf.jet.exceptions.JPFException;
import gov.nasa.jpf.jet.ui.helpers.prefs.ifaces.JetPropertyChangeListener;
import gov.nasa.jpf.jet.ui.helpers.prefs.models.JPFExtension;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import org.eclipse.core.runtime.CoreException;

public class JetSiteResourceManager {

	@SuppressWarnings("serial")
	private class SiteProperties extends Properties {

		static final char KEY_PREFIX = '@';
		static final String REQUIRES_KEY = "@requires";
		static final String INCLUDE_KEY = "@include";
		static final String INCLUDE_UNLESS_KEY = "@include_unless";
		static final String INCLUDE_IF_KEY = "@include_if";

		static final String TRUE = "true";
		static final String FALSE = "false";

		final char[] DELIMS = { ',', ';' };

		// where did we initialize from
		ArrayList<Object> sources = new ArrayList<Object>();

		// Properties are simple Hashmaps, but we want to maintain the order of
		// entries
		LinkedList<String> entrySequence = new LinkedList<String>();

		// bad - a control exception
		class MissingRequiredKeyException extends RuntimeException {
			MissingRequiredKeyException(String details) {
				super(details);
			}
		}

		// we override this so that we can handle expansion for both key and
		// value
		// (value expansion can be recursive, i.e. refer to itself)
		@Override
		public synchronized Object put(Object keyObject, Object valueObject) {

			if (keyObject == null) {
				throw exception("no null keys allowed");
			} else if (!(keyObject instanceof String)) {
				throw exception("only String keys allowed, got: " + keyObject);
			}
			if (valueObject != null && !(valueObject instanceof String)) {
				throw exception("only String or null values allowed, got: "
						+ valueObject);
			}

			String key = (String) keyObject;
			String value = (String) valueObject;

			if (key.length() == 0) {
				throw exception("no empty keys allowed");
			}

			if (key.charAt(0) == KEY_PREFIX) {

				if (REQUIRES_KEY.equals(key)) {
					// shortcircuit loading of property files - used to enforce
					// order
					// of properties, e.g. to model dependencies
					for (String reqKey : split(value)) {
						if (!containsKey(reqKey)) {
							throw new MissingRequiredKeyException(reqKey);
						}
					}
					return null;

				} else if (INCLUDE_KEY.equals(key)) {
					includePropertyFile(key, value);
					return null;
				} else if (INCLUDE_UNLESS_KEY.equals(key)) {
					includeCondPropertyFile(key, value, false);
					return null;
				} else if (INCLUDE_IF_KEY.equals(key)) {
					includeCondPropertyFile(key, value, true);
					return null;
				} else {
					throw exception("unknown keyword: " + key);
				}

			}
			// finally, a real key/value pair to add (or remove) - expand
			// and store
			String k = expandString(null, key);

			if (!(value == null)) { // add or overwrite entry
				String v = (String) value;

				if (k.charAt(k.length() - 1) == '+') { // the append hack
					k = k.substring(0, k.length() - 1);
					return append(k, v, null);

				} else if (k.charAt(0) == '+') { // the prepend hack
					k = k.substring(1);
					return prepend(k, v, null);

				} else { // normal value set
					v = normalize(expandString(k, v));
					if (v != null) {
						return setKey(k, v);
					}
					return removeKey(k);
				}

			}
			// setting a null value removes the entry
			return removeKey(k);
		}

		private Object removeKey(String k) {
			Object oldValue = super.get(k);
			remove0(k);
			// notifyPropertyChangeListeners(k, (String) oldValue, null);
			return oldValue;
		}

		private Object remove0(String k) {
			entrySequence.add(k);
			return super.remove(k);
		}

		private Object setKey(String k, String v) {
			Object oldValue = put0(k, v);
			// notifyPropertyChangeListeners(k, (String) oldValue, v);
			return oldValue;
		}

		protected String prepend(String key, String value, String separator) {
			String oldValue = getProperty(key);
			value = normalize(expandString(key, value));

			append0(key, oldValue, value, oldValue, separator);

			return oldValue;
		}

		protected String append(String key, String value, String separator) {
			String oldValue = getProperty(key);
			value = normalize(expandString(key, value));

			append0(key, oldValue, oldValue, value, separator);

			return oldValue;
		}

		/**
		 * replace string constants with global static objects
		 */
		protected String normalize(String v) {
			if (v == null) {
				return null; // ? maybe TRUE - check default loading of "key" or
								// "key="
			}

			// trim leading and trailing blanks (at least Java 1.4.2 does not
			// take care of trailing blanks)
			v = v.trim();

			// true/false
			if ("true".equalsIgnoreCase(v) || "t".equalsIgnoreCase(v)
					|| "yes".equalsIgnoreCase(v) || "y".equalsIgnoreCase(v)
					|| "on".equalsIgnoreCase(v)) {
				v = TRUE;
			} else if ("false".equalsIgnoreCase(v) || "f".equalsIgnoreCase(v)
					|| "no".equalsIgnoreCase(v) || "n".equalsIgnoreCase(v)
					|| "off".equalsIgnoreCase(v)) {
				v = FALSE;
			}

			// nil/null
			if ("nil".equalsIgnoreCase(v) || "null".equalsIgnoreCase(v)) {
				v = null;
			}

			return v;
		}

		private void append0(String key, String oldValue, String a, String b,
				String separator) {
			String newValue;

			if (a != null) {
				if (b != null) {
					StringBuilder sb = new StringBuilder(a);
					if (separator != null) {
						sb.append(separator);
					}
					sb.append(b);
					newValue = sb.toString();

				} else { // b==null : nothing to append
					if (oldValue == a) { // using reference compare is
											// intentional here
						return; // no change
					} else {
						newValue = a;
					}
				}

			} else { // a==null : nothing to append to
				if (oldValue == b || b == null) { // using reference compare is
													// intentional here
					return; // no change
				} else {
					newValue = b;
				}
			}

			// if we get here, we have a newValue that differs from oldValue
			put0(key, newValue);
			// notifyPropertyChangeListeners(key, oldValue, newValue);
		}

		private Object put0(String k, Object v) {
			entrySequence.add(k);
			return super.put(k, v);
		}

		void includeCondPropertyFile(String key, String value,
				boolean keyPresent) {
			value = expandString(key, value);
			if (value != null && value.length() > 0) {
				// check if it's a conditional
				// "@include_unless/if = ?key?pathName"
				if (value.charAt(0) == '?') {
					int idx = value.indexOf('?', 1);
					if (idx > 1) {
						String k = value.substring(1, idx);
						if (containsKey(k) == keyPresent) {
							String v = value.substring(idx + 1);
							if (v.length() > 0) {
								loadPropertiesRecursive(v);
							} else {
								throw exception("@include_unless pathname argument missing (?<key>?<pathName>)");
							}
						}

					} else {
						throw exception("malformed @include_unless argument (?<key>?<pathName>), found: "
								+ value);
					}
				} else {
					throw exception("malformed @include_unless argument (?<key>?<pathName>), found: "
							+ value);
				}
			} else {
				throw exception("@include_unless missing ?<key>?<pathName> argument");
			}
		}

		public JPFException exception(String msg) {
			String context = getString("config");
			if (context != null) {
				msg = "error in " + context + " : " + msg;
			}

			return new JPFConfigException(msg);
		}

		public String getString(String key) {
			return getProperty(key);
		}

		/**
		 * our own version of split, which handles "`" quoting, and breaks on
		 * non-quoted ',' and ';' chars. We need this so that we can use ';'
		 * separated lists in JPF property files, but still can use quoted ';'
		 * if we absolutely have to specify Java signatures. On the other hand,
		 * we can't quote with '\' because that would make Windows paths even
		 * more terrible. regexes are bad at quoting, and this is more efficient
		 * anyways
		 */
		protected String[] split(String input) {
			return split(input, DELIMS);
		}

		protected String[] split(String input, char[] delim) {
			int n = input.length();
			ArrayList<String> elements = new ArrayList<String>();
			boolean quote = false;

			char[] buf = new char[128];
			int k = 0;

			for (int i = 0; i < n; i++) {
				char c = input.charAt(i);

				if (!quote) {
					if (isDelim(delim, c)) { // element separator
						elements.add(new String(buf, 0, k));
						k = 0;
						continue;
					} else if (c == '`') {
						quote = true;
						continue;
					}
				}

				if (k >= buf.length) {
					char[] newBuf = new char[buf.length + 128];
					System.arraycopy(buf, 0, newBuf, 0, k);
					buf = newBuf;
				}
				buf[k++] = c;
				quote = false;
			}

			if (k > 0) {
				elements.add(new String(buf, 0, k));
			}

			return elements.toArray(new String[elements.size()]);
		}

		private boolean isDelim(char[] delim, char c) {
			for (int i = 0; i < delim.length; i++) {
				if (c == delim[i]) {
					return true;
				}
			}
			return false;
		}

		void includePropertyFile(String key, String value) {
			value = expandString(key, value);
			if (value != null && value.length() > 0) {
				loadPropertiesRecursive(value);
			} else {
				throw exception("@include pathname argument missing");
			}
		}

		// our internal expander
		// Note that we need to know the key this came from, to handle recursive
		// expansion
		protected String expandString(String key, String s) {
			int i, j = 0;
			if (s == null || s.length() == 0) {
				return s;
			}

			while ((i = s.indexOf("${", j)) >= 0) {
				if ((j = s.indexOf('}', i)) > 0) {
					String k = s.substring(i + 2, j);
					String v;

					if ((key != null) && key.equals(k)) {
						// that's expanding itself -> use what is there
						v = getProperty(key);
					} else {
						// refers to another key, which is already expanded, so
						// this
						// can't get recursive (we expand during entry storage)
						v = getProperty(k);
					}

					if (v == null) { // if we don't have it, fall back to system
										// properties
						v = System.getProperty(k);
					}

					if (v != null) {
						s = s.substring(0, i) + v
								+ s.substring(j + 1, s.length());
						j = i + v.length();
					} else {
						s = s.substring(0, i) + s.substring(j + 1, s.length());
						j = i;
					}
				}
			}

			return s;
		}

		boolean loadPropertiesRecursive(String fileName) {
			// save the current values of automatic properties
			String curConfig = (String) get("config");
			String curConfigPath = (String) get("config_path");

			File propFile = new File(fileName);
			if (!propFile.isAbsolute()) {
				propFile = new File(curConfigPath, fileName);
			}
			String absPath = propFile.getAbsolutePath();

			if (!propFile.isFile()) {
				throw exception("property file does not exist: " + absPath);
			}

			boolean ret = loadProperties(absPath);

			// restore the automatic properties
			super.put("config", curConfig);
			super.put("config_path", curConfigPath);

			return ret;
		}

		protected boolean loadProperties(String fileName) {
			if (fileName != null && fileName.length() > 0) {
				FileInputStream is = null;
				try {
					File f = new File(fileName);
					if (f.isFile()) {
						setConfigPathProperties(f.getAbsolutePath());
						sources.add(f);
						is = new FileInputStream(f);
						load(is);
						return true;
					} else {
						throw exception("property file does not exist: "
								+ f.getAbsolutePath());
					}
				} catch (MissingRequiredKeyException rkx) {
					// Hmpff - control exception
				} catch (IOException iex) {
					throw new JPFConfigException("error loading properties: "
							+ fileName, iex);
				} finally {
					if (is != null) {
						try {
							is.close();
						} catch (IOException iox1) {
						}
					}
				}
			}

			return false;
		}

		protected void setConfigPathProperties(String fileName) {
			put("config", fileName);
			int i = fileName.lastIndexOf(File.separatorChar);
			if (i >= 0) {
				put("config_path", fileName.substring(0, i));
			} else {
				put("config_path", ".");
			}
		}
	}

	/**
	 * This is set true when there are changes to be made to the property file.
	 */
	private boolean isDirty = false;

	/**
	 * Hangs onto any listeners that this may have
	 */
	private List<JetPropertyChangeListener> listeners = new ArrayList<JetPropertyChangeListener>(
			3);

	private String sitePath;

	private SiteProperties site = new SiteProperties();

	private static final String JPF_CORE = "jpf-core";

	private static final String SYS_HOME = System.getProperty("user.home")
			.replace('\\', '/');

	private static List<String> potentialDefaults = new ArrayList<String>(
			Arrays.asList(JPF_CORE));

	/**
	 * Creates a default instance of the PropertyManager. Loads values from file
	 * "jpf.properties", then loads values from the config file specified.
	 * 
	 * @param configFile
	 *            the file that properties and loaded from and stored to.
	 * @param project
	 *            the project used to determine the VJP properties
	 * @throws IOException
	 */
	public JetSiteResourceManager(String sitePath) {
		this.sitePath = sitePath;
	}

	/**
	 * Clears all of the config properties contained and then reloads all
	 * properties from the configuration file. NOTE: this does not reload from
	 * jpf.properties or default.properties
	 * 
	 * @return
	 * 
	 * @throws IOException
	 *             if the file can not be read
	 * @throws CoreException
	 *             if the file can not be found
	 */
	public void getFromFile(Collection<JPFExtension> included,
			Collection<JPFExtension> excluded) {
		included.clear();
		excluded.clear();
		site.clear();
		loadFromFile(included, excluded);
	}

	/**
	 * Loads this configuration with the properties contained in configuration
	 * file associated.
	 * 
	 * @throws IOException
	 * @throws CoreException
	 * @return the HashMap that contains all of the properties loaded from
	 *         jpf.properties and default.properties
	 */
	private void loadFromFile(Collection<JPFExtension> included,
			Collection<JPFExtension> excluded) {
		InputStream input = null;
		try {
			input = new FileInputStream(sitePath);
		} catch (FileNotFoundException fnfe) {
			testAndSetDefaults(included, excluded);
			return;
		}

		try {
			site.load(input);
			input.close();
		} catch (IOException e) {
			JetPlugin.logError("Error while reading site.propertes", e);
			testAndSetDefaults(included, excluded);
			return;
		}

		// we get the property back as a fully-expanded path
		String pathsAsString =  site.getProperty("extensions");
		if (pathsAsString != null) {
			String[] paths = pathsAsString.split(",");
			site.remove("extensions");
			List<String> includedExtPaths = Arrays.asList(paths);
			
			HashMap<String, JPFExtension> pathLookup = new HashMap<String, JPFExtension>();
			
			// *** WE ASSUME TWO EXTENSIONS WILL NOT HAVE SAME PATH ***
			for (Object obj : site.keySet()) {
				String extName = (String) obj;
				String extPath = (String) site.get(extName);
				pathLookup.put(extPath,
						new JPFExtension(extName, extPath.replace('\\', '/')));
			}
			
			// Add each included extension IN ORDER
			for (String path : includedExtPaths) {
				JPFExtension ext = pathLookup.get(path);
				// ignore paths that don't have a corresponding extension
				if (ext != null) {
					included.add(ext);
					pathLookup.remove(path);
				}
			}
			
			// Add the rest as excluded
			for (String path : pathLookup.keySet()) {
				excluded.add(pathLookup.get(path));
			}
		}

		testAndSetDefaults(included, excluded);
	}

	// ensure that jpf-core exists and is at the top
	private void testAndSetDefaults(Collection<JPFExtension> included,
			Collection<JPFExtension> excluded) {
		ArrayList<String> namesIncluded = new ArrayList<String>();
		HashMap<String, JPFExtension> includeMap = new HashMap<String, JPFExtension>();
		HashMap<String, JPFExtension> excludeMap = new HashMap<String, JPFExtension>();
		for (JPFExtension ext : included) {
			String name = ext.getName();
			namesIncluded.add(name);
			includeMap.put(name, ext);
		}
		for (JPFExtension ext : excluded) {
			excludeMap.put(ext.getName(), ext);
		}
		boolean setDirty = false;
		for (String key : potentialDefaults) {
			// if default not found in included list
			if (!namesIncluded.contains(key)) {
				JPFExtension ext = excludeMap.get(key);
				// but if it is found in excluded list
				if (ext != null) {
					excluded.remove(ext);
				}
				Collection<JPFExtension> oldValues = new ArrayList<JPFExtension>(
						included);
				included.clear();
				included.add(new JPFExtension(key, SYS_HOME.concat(
						"/projects/jpf/").concat(key)));
				included.addAll(oldValues);
				setDirty = true;
			} else { // default is found in included list
				// but is not the first element
				if (!namesIncluded.get(0).equals(key)) {
					// then make it the first element
					JPFExtension ext = includeMap.get(key);
					included.remove(ext);
					Collection<JPFExtension> oldValues = new ArrayList<JPFExtension>(
							included);
					included.clear();
					included.add(ext);
					included.addAll(oldValues);
					setDirty = true;
				}
			}
		}
		if (setDirty) {
			setDirty(setDirty);
		}
	}

	public void save(Collection<JPFExtension> included,
			Collection<JPFExtension> excluded) throws IOException {
		File file = new File(sitePath);
		PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(
				file)));

		StringBuffer extMacros = new StringBuffer();
		String extName;
		boolean first = true;
		for (JPFExtension ext : included) {
			extName = ext.getName();
			writer.println(extName + " = " + replaceSysHome(ext.getLocation()));
			if (first) {
				extMacros.append("${" + extName + "}");
				first = false;
			} else {
				extMacros.append(",${" + extName + "}");
			}
		}
		for (JPFExtension ext : excluded) {
			writer.println(ext.getName() + " = "
					+ replaceSysHome(ext.getLocation()));
		}
		writer.println("extensions=" + extMacros.toString());

		writer.flush();
		writer.close();

		setDirty(false);
	}

	private String replaceSysHome(String extVal) {
		String retVal = extVal;
		int last = retVal.indexOf(SYS_HOME);
		if (last != -1) {
			String after = retVal.substring(last + SYS_HOME.length());
			retVal = "${user.home}".concat(after);
		}
		return retVal;
	}

	/**
	 * @return true if there are properties that need to be saved to a file.
	 */
	public boolean isDirty() {
		return isDirty;
	}

	public void setDirty(boolean isDirty) {
		this.isDirty = isDirty;
		if (isDirty()) {
			fireListeners();
		}
	}

	/**
	 * Adds a change listener to this configuration. Change listeners are fired
	 * once this configuration becomes dirty.
	 * 
	 * @param listener
	 *            adds the listener to this configuration.
	 */
	public void addChangeListener(JetPropertyChangeListener listener) {
		listeners.add(listener);
	}

	public List<JetPropertyChangeListener> getChangeListeners() {
		return listeners;
	}

	/**
	 * Removes this change listener from this configuration.
	 * 
	 * @param listener
	 *            the listener to be removed from this configuration.
	 */
	public void removeChangeListener(JetPropertyChangeListener listener) {
		listeners.remove(listener);
	}

	private void fireListeners() {
		for (JetPropertyChangeListener listener : listeners)
			listener.changeOccurred();
	}

}
