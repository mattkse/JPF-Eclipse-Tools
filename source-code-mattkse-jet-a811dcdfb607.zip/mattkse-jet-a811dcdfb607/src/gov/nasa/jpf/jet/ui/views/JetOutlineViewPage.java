package gov.nasa.jpf.jet.ui.views;

import org.eclipse.jdt.core.IMember;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.internal.corext.util.JdtFlags;
import org.eclipse.jdt.internal.ui.javaeditor.JavaEditor;
import org.eclipse.jdt.internal.ui.javaeditor.JavaOutlinePage;
import org.eclipse.jdt.ui.IContextMenuConstants;
import org.eclipse.jdt.ui.actions.CCPActionGroup;
import org.eclipse.jdt.ui.actions.GenerateActionGroup;
import org.eclipse.jdt.ui.actions.JavaSearchActionGroup;
import org.eclipse.jdt.ui.actions.OpenViewActionGroup;
import org.eclipse.jdt.ui.actions.RefactorActionGroup;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.actions.ActionContext;
import org.eclipse.ui.actions.ActionGroup;
import org.eclipse.ui.navigator.ICommonMenuConstants;
import org.eclipse.jdt.internal.ui.actions.CompositeActionGroup;

@SuppressWarnings("restriction")
public class JetOutlineViewPage extends JavaOutlinePage {
	
	private CompositeActionGroup fActionGroups;

	public JetOutlineViewPage(String contextMenuID, JavaEditor editor) {
		super(contextMenuID, editor);
	}
	
	protected void contextMenuAboutToShow(IMenuManager menu) {
//		TreeSelection sel = (TreeSelection) this.getSite().getSelectionProvider().getSelection();
		IStructuredSelection selection= (IStructuredSelection)getSelection();
		try {
			// we must create the groups after we have set the selection provider to the site
			if (JdtFlags.isNative((IMember) selection.getFirstElement())) {
				fActionGroups= new CompositeActionGroup(new ActionGroup[] {
						new JetNavActionGroup(this),
						new OpenViewActionGroup(this),
						new CCPActionGroup(this),
						new GenerateActionGroup(this),
						new RefactorActionGroup(this),
						new JavaSearchActionGroup(this)});
			} else {
				fActionGroups= new CompositeActionGroup(new ActionGroup[] {
						new OpenViewActionGroup(this),
						new CCPActionGroup(this),
						new GenerateActionGroup(this),
						new RefactorActionGroup(this),
						new JavaSearchActionGroup(this)});
			}
		} catch (JavaModelException e) {
			e.printStackTrace();
		}

		createStandardGroups(menu);
		
		fActionGroups.setContext(new ActionContext(selection));
		fActionGroups.fillContextMenu(menu);
	}
	
	/**
	 * Creates the Java plug-in's standard groups for view context menus.
	 *
	 * @param menu the menu manager to be populated
	 */
	public void createStandardGroups(IMenuManager menu) {
		if (!menu.isEmpty())
			return;

		menu.add(new Separator(IContextMenuConstants.GROUP_NEW));
		menu.add(new GroupMarker(IContextMenuConstants.GROUP_GOTO));
		menu.add(new Separator("group.jpf"));
		menu.add(new Separator(IContextMenuConstants.GROUP_OPEN));
//		menu.add(new Separator(IContextMenuConstants.GROUP_OPEN));
		menu.add(new GroupMarker(IContextMenuConstants.GROUP_SHOW));
		menu.add(new Separator(ICommonMenuConstants.GROUP_EDIT));
		menu.add(new Separator(IContextMenuConstants.GROUP_REORGANIZE));
		menu.add(new Separator(IContextMenuConstants.GROUP_GENERATE));
		menu.add(new Separator(IContextMenuConstants.GROUP_SEARCH));
		menu.add(new Separator(IContextMenuConstants.GROUP_BUILD));
		menu.add(new Separator(IContextMenuConstants.GROUP_ADDITIONS));
		menu.add(new Separator(IContextMenuConstants.GROUP_VIEWER_SETUP));
		menu.add(new Separator(IContextMenuConstants.GROUP_PROPERTIES));
	}

}
