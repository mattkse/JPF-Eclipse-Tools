package gov.nasa.jpf.jet.ui.views;

import gov.nasa.jpf.jet.ui.actions.JetOpenPeerAction;

import org.eclipse.jdt.ui.actions.JdtActionConstants;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IWorkbenchSite;
import org.eclipse.ui.actions.ActionGroup;
import org.eclipse.ui.part.Page;

/**
 * Context menu for JET Peer Outline
 */
public class JetNavActionGroup extends ActionGroup {
	
	private JetOpenPeerAction fOpenPeer;
	
	private ISelectionProvider fSelectionProvider;
	
	/**
	 * Creates a new <code>JetNavActionGroup</code>. The group requires
	 * that the selection provided by the page's selection provider is
	 * of type {@link IStructuredSelection}.
	 *
	 * @param page the page that owns this action group
	 */
	public JetNavActionGroup(Page page) {
		createSiteActions(page.getSite(), null);
	}
	
	private void createSiteActions(IWorkbenchSite site, ISelectionProvider specialProvider) {
		fOpenPeer = new JetOpenPeerAction(site);
		
//		fOpenPeer.setActionDefinitionId(IJavaEditorActionDefinitionIds.OPEN_IMPLEMENTATION);
//		fOpenPeer.setSpecialSelectionProvider(specialProvider);
		
		ISelectionProvider provider= specialProvider != null ? specialProvider : site.getSelectionProvider();
		initialize(provider);
	}
	
	private void initialize(ISelectionProvider provider) {
		fSelectionProvider = provider;
		ISelection selection = provider.getSelection();
		fOpenPeer.update(selection);

		provider.addSelectionChangedListener(fOpenPeer);
	}
	
	/* (non-Javadoc)
	 * Method declared in ActionGroup
	 */
	public void fillActionBars(IActionBars actionBar) {
		super.fillActionBars(actionBar);
		setGlobalActionHandlers(actionBar);
	}
	
	private void setGlobalActionHandlers(IActionBars actionBars) {
		actionBars.setGlobalActionHandler(JdtActionConstants.OPEN_CALL_HIERARCHY, fOpenPeer);
	}
	
	/* (non-Javadoc)
	 * Method declared in ActionGroup
	 */
	@Override
	public void fillContextMenu(IMenuManager menu) {
		super.fillContextMenu(menu);
		appendToGroup(menu, fOpenPeer);
	}
	
	private void appendToGroup(IMenuManager menu, IAction action) {
//		if (action.isEnabled())
			menu.appendToGroup("group.jpf", action);
	}
}
