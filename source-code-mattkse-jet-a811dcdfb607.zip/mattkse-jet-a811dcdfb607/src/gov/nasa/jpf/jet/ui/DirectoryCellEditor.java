//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.jet.ui;

import java.text.MessageFormat;

import org.eclipse.core.runtime.Path;
import org.eclipse.jface.viewers.DialogCellEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Layout;
import org.eclipse.swt.widgets.Text;

/**
 * A cell editor that manages a color field. The cell editor's value is the
 * color (an SWT <code>RBG</code>).
 * <p>
 * This class may be instantiated; it is not intended to be subclassed.
 * </p>
 * 
 * @noextend This class is not intended to be subclassed by clients.
 */
public class DirectoryCellEditor extends DialogCellEditor {

	/**
	 * Internal class for laying out this cell editor.
	 */
	private class DirectoryCellLayout extends Layout {
		public DirectoryCellLayout() {
		}

		@Override
		public Point computeSize(Composite editor, int wHint, int hHint,
				boolean force) {
			if (wHint != SWT.DEFAULT && hHint != SWT.DEFAULT) {
				return new Point(wHint, hHint);
			}
			Point pathSize = pathText.computeSize(SWT.DEFAULT, SWT.DEFAULT,
					force);
			return new Point(pathSize.x, pathSize.y);
		}

		@Override
		public void layout(Composite editor, boolean force) {
			Rectangle bounds = editor.getClientArea();
			Point pathSize = pathText.computeSize(SWT.DEFAULT, SWT.DEFAULT,
					force);
			int ty = (bounds.height - pathSize.y) / 2;
			if (ty < 0) {
				ty = 0;
			}
			pathText.setBounds(-1, ty, bounds.width, bounds.height);
		}
	}

	/**
	 * The composite widget containing the color and RGB label widgets
	 */
	private Composite composite;

	/**
	 * The label widget showing the path values.
	 */
	private Text pathText;

	private ModifyListener modifyListener;

	private static final String defaultPath = System.getProperty("user.home");

	/**
	 * Default TextCellEditor style specify no borders on text widget as cell
	 * outline in table already provides the look of a border.
	 */
	private static final int defaultStyle = SWT.SINGLE;

	/**
	 * Creates a new color cell editor parented under the given control. The
	 * cell editor value is black (<code>RGB(0,0,0)</code>) initially, and has
	 * no validator.
	 * 
	 * @param parent
	 *            the parent control
	 */
	public DirectoryCellEditor(Composite parent) {
		this(parent, defaultStyle);
	}

	/**
	 * Creates a new color cell editor parented under the given control. The
	 * cell editor value is black (<code>RGB(0,0,0)</code>) initially, and has
	 * no validator.
	 * 
	 * @param parent
	 *            the parent control
	 * @param style
	 *            the style bits
	 * @since 2.1
	 */
	public DirectoryCellEditor(Composite parent, int style) {
		super(parent, style);
		doSetValue(defaultPath);
	}

	/*
	 * (non-Javadoc) Method declared on DialogCellEditor.
	 */
	@Override
	protected Control createContents(Composite cell) {
		Color bg = cell.getBackground();
		composite = new Composite(cell, getStyle());
		composite.setBackground(bg);
		composite.setLayout(new DirectoryCellLayout());
		pathText = new Text(composite, getStyle());
		pathText.setBackground(bg);
		pathText.setFont(cell.getFont());
		pathText.setText("");
		pathText.addModifyListener(getModifyListener());
		return composite;
	}

	/**
	 * Return the modify listener.
	 */
	private ModifyListener getModifyListener() {
		if (modifyListener == null) {
			modifyListener = new ModifyListener() {
				@Override
				public void modifyText(ModifyEvent e) {
					editOccured(e);
				}
			};
		}
		return modifyListener;
	}

	/**
	 * Processes a modify event that occurred in this text cell editor. This
	 * framework method performs validation and sets the error message
	 * accordingly, and then reports a change via
	 * <code>fireEditorValueChanged</code>. Subclasses should call this method
	 * at appropriate times. Subclasses may extend or reimplement.
	 * 
	 * @param e
	 *            the SWT modify event
	 */
	protected void editOccured(ModifyEvent e) {
		String value = pathText.getText();
		if (value == null) {
			value = "";//$NON-NLS-1$
		}
		Object typedValue = value;
		boolean oldValidState = isValueValid();
		boolean newValidState = isCorrect(typedValue);
		if (!newValidState) {
			// try to insert the current value into the error message.
			setErrorMessage(MessageFormat.format(getErrorMessage(),
					new Object[] { value }));
		}
		valueChanged(oldValidState, newValidState);
	}

	/*
	 * (non-Javadoc) Method declared on DialogCellEditor.
	 */
	@Override
	protected Object openDialogBox(Control cellEditorWindow) {
		DirectoryDialog dialog = new DirectoryDialog(
				cellEditorWindow.getShell(), SWT.SHEET);
		Object value = getValue();
		if (value != null) {
			dialog.setFilterPath((String) value);
		}
		value = dialog.open();
		if (value != null) {
			value = new Path((String) value).makeAbsolute().toOSString()
					.replace('\\', '/');
		}
		return value;
	}

	/*
	 * (non-Javadoc) Method declared on DialogCellEditor.
	 */
	@Override
	protected void updateContents(Object value) {
		String dir = (String) value;
		// XXX: We don't have a value the first time this method is called".
		if (dir == null) {
			dir = defaultPath;
		}

		pathText.setText(dir);
	}
}
