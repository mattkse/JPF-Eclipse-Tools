//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.jet.ui.wizards;

import org.eclipse.core.filesystem.URIUtil;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;

import gov.nasa.jpf.template.CreateProject;

import java.io.File;
import java.net.URI;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.wizard.WizardPage;
//import org.eclipse.pde.internal.ui.IHelpContextIds;
import org.eclipse.osgi.util.TextProcessor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.*;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.*;

/**
 * The first page of the New JPF Project wizard.
 */
public class NewVerifyProjectWizardMainPage extends WizardPage {

	private static final String defaultCorePath = System
			.getProperty("user.home").concat("/projects/jpf/jpf-core")
			.replace('\\', '/');

	// initial value stores
	/*
	 * @see org.eclipse.ui.internal.ide.dialogs.ProjectContentsLocationArea#
	 * existingProject
	 */
	private IProject existingProject;
	/*
	 * @see org.eclipse.ui.dialogs.WizardNewProjectCreationPage#initialProjectFieldValue
	 */
	private String initialProjectFieldValue;
	/*
	 * @see
	 * org.eclipse.ui.internal.ide.dialogs.ProjectContentsLocationArea#userPath
	 */
	// private String userProjectPath = "";
	// private String userCorePath = "";
	/*
	 * @see
	 * org.eclipse.ui.internal.ide.dialogs.ProjectContentsLocationArea#projectName
	 */
	private String projectName = "";
	/**
	 * @see org.eclipse.jface.preference.DirectoryFieldEditor#filterPath
	 */
	private File filterPath = null;

	// widgets
	private Text projectNameField;
	Button projectDefaultLocationButton;
	// Label projectLocationLabel;
	// Composite projectLocationTextComposite;
	// Text projectLocationTextField;
	// Button projectLocationBrowseButton;
	Button fUseDefaultCorePathButton;
	// Label fCorePathLabel;
	// Composite corePathTextComposite;
	// private Text fCorePathText;
	// private Button fCorePathBrowseButton;

	// constants
	private static final String PAGE_NAME = "NewVerifyProjectWizardMainPage";
	/*
	 * @see
	 * org.eclipse.ui.internal.ide.dialogs.ProjectContentsLocationArea#FILE_SCHEME
	 */
	private static final String FILE_SCHEME = "file";
	/*
	 * @see org.eclipse.ui.dialogs.WizardNewProjectCreationPage#SIZING_TEXT_FIELD_WIDTH
	 */
	private static final int SIZING_TEXT_FIELD_WIDTH = 250;

	private static enum LocationTypes {
		PROJECT_LOCATION(null, null, null, null, ""), CORE_PATH_LOCATION(null,
				null, null, null, "");

		Label label;
		Composite textComposite;
		Text text;
		Button button;
		/*
		 * @see
		 * org.eclipse.ui.internal.ide.dialogs.ProjectContentsLocationArea#userPath
		 */
		String userPath;

		private LocationTypes(Label label, Composite textComposite, Text text,
				Button button, String userPath) {
			this.label = label;
			this.textComposite = textComposite;
			this.text = text;
			this.button = button;
			this.userPath = userPath;
		}
	}

	// final Controls [] CONTROLS = {
	// new Controls (getProjectLabel(), getProjectTextComposite(),
	// getProjectText(), getProjectButton(), getProjectUserPath()),
	// new Controls (getCorePathLabel(), getCorePathTextComposite(),
	// getCorePathText(), getCorePathButton(), getCorePathUserPath()),
	// };

	// private Label getProjectLabel() {
	// return projectLocationLabel;
	// }
	//
	// private Composite getProjectTextComposite() {
	// return projectLocationTextComposite;
	// }
	//
	// private Text getProjectText() {
	// return projectLocationTextField;
	// }
	//
	// private Button getProjectButton() {
	// return projectLocationBrowseButton;
	// }
	//
	// private String getProjectUserPath() {
	// return userProjectPath;
	// }
	//
	// private Label getCorePathLabel() {
	// return fCorePathLabel;
	// }
	//
	// private Composite getCorePathTextComposite() {
	// return corePathTextComposite;
	// }
	//
	// private Text getCorePathText() {
	// return fCorePathText;
	// }
	//
	// private Button getCorePathButton() {
	// return fCorePathBrowseButton;
	// }
	//
	// private String getCorePathUserPath() {
	// return userCorePath;
	// }

	/**
	 * Creates a new project creation wizard page.
	 * 
	 * @param pageName
	 *            the name of this page
	 */
	public NewVerifyProjectWizardMainPage() {
		super(PAGE_NAME);
		setTitle("Create a JPF Project");
		setDescription("Enter a Project name.");
	}

	/*
	 * @see org.eclipse.ui.dialogs.WizardNewProjectCreationPage#createControl(Composite
	 *      parent)
	 */
	@Override
	public void createControl(Composite parent) {
		Composite composite = new Composite(parent, SWT.NULL);

		initializeDialogUnits(parent);

		// TODO: INSTALL WIZARD HELP
		// PlatformUI.getWorkbench().getHelpSystem().setHelp(composite,
		// IIDEHelpContextIds.NEW_PROJECT_WIZARD_PAGE);

		composite.setLayout(new GridLayout());
		composite.setLayoutData(new GridData(GridData.FILL_BOTH));

		createProjectNameGroup(composite);

		createProjectLocationArea(composite);
		if (initialProjectFieldValue != null) {
			updateProjectName(initialProjectFieldValue);
		}

		// Scale the button based on the rest of the dialog
		setButtonLayoutData(LocationTypes.PROJECT_LOCATION.button);

		createCorePathLocationArea(composite);

		// setLocationControls();

		setPageComplete(validatePage());

		// Show description on opening
		setErrorMessage(null);
		setMessage(null);
		setControl(composite);
		Dialog.applyDialogFont(composite);
	}

	// private void setLocationControls() {
	// LocationTypes.PROJECT_LOCATION.label = projectLocationLabel;
	// LocationTypes.PROJECT_LOCATION.textComposite =
	// projectLocationTextComposite;
	// LocationTypes.PROJECT_LOCATION.text = projectLocationTextField;
	// LocationTypes.PROJECT_LOCATION.button = projectLocationBrowseButton;
	// LocationTypes.PROJECT_LOCATION.userPath = userProjectPath;
	// LocationTypes.CORE_PATH_LOCATION.label = fCorePathLabel;
	// LocationTypes.CORE_PATH_LOCATION.textComposite = corePathTextComposite;
	// LocationTypes.CORE_PATH_LOCATION.text = fCorePathText;
	// LocationTypes.CORE_PATH_LOCATION.button = fCorePathBrowseButton;
	// LocationTypes.CORE_PATH_LOCATION.userPath = userCorePath;
	// }

	/*
	 * @see org.eclipse.ui.dialogs.WizardNewProjectCreationPage#createProjectNameGroup(Composite
	 *      parent)
	 */
	private final void createProjectNameGroup(Composite parent) {
		// project specification group
		Composite projectGroup = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		projectGroup.setLayout(layout);
		projectGroup.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		// new project label
		Label projectLabel = new Label(projectGroup, SWT.NONE);
		projectLabel.setText("&Project name:");
		projectLabel.setFont(parent.getFont());

		// new project name entry field
		projectNameField = new Text(projectGroup, SWT.BORDER);
		GridData data = new GridData(GridData.FILL_HORIZONTAL);
		data.widthHint = SIZING_TEXT_FIELD_WIDTH;
		projectNameField.setLayoutData(data);
		projectNameField.setFont(parent.getFont());

		// Set the initial value first before listener
		// to avoid handling an event during the creation.
		if (initialProjectFieldValue != null) {
			projectNameField.setText(initialProjectFieldValue);
		}
		projectNameField.addListener(SWT.Modify, new Listener() {
			/*
			 * @see org.eclipse.ui.dialogs.WizardNewProjectCreationPage#nameModifyListener
			 */
			@Override
			public void handleEvent(Event e) {
				setLocationForSelection();
				boolean valid = validatePage();
				setPageComplete(valid);
			}
		});
	}

	/*
	 * @see org.eclipse.ui.dialogs.WizardNewProjectCreationPage#setLocationForSelection()
	 */
	void setLocationForSelection() {
		updateProjectName(getProjectNameFieldValue());
	}

	/*
	 * @see org.eclipse.ui.internal.ide.dialogs.ProjectContentsLocationArea#
	 * createContents(Composite composite, boolean defaultEnabled)
	 */
	private void createProjectLocationArea(Composite composite) {
		int columns = 4;

		Composite projectGroup = new Composite(composite, SWT.NONE);
		GridLayout layout = new GridLayout();
		layout.numColumns = columns;
		projectGroup.setLayout(layout);
		projectGroup.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		// use default button
		projectDefaultLocationButton = createUseDefaultButton(projectGroup,
				columns, LocationTypes.PROJECT_LOCATION);

		createProjectLocationControls(projectGroup, columns - 1);
	}

	Text recreateProjectTextField(Text text, Composite parent,
			LocationTypes type, boolean defaultSelected) {
		int options;
		String newTextContents;
		if (defaultSelected) {
			options = SWT.READ_ONLY;
			type.userPath = text.getText();
			newTextContents = TextProcessor
					.process((type == LocationTypes.PROJECT_LOCATION) ? getDefaultPathDisplayString() : defaultCorePath);
		} else {
			options = SWT.NONE;
			newTextContents = TextProcessor.process(type.userPath);
		}
		text.dispose();
		Text newText = createLocationText(parent, 2, options);
		newText.setText(newTextContents);
		parent.layout(); // text field won't repaint without this line
		return newText;
	}

	/**
	 * @see org.eclipse.jface.preference.StringFieldEditor#doFillIntoGrid(Composite
	 *      parent, int numColumns)
	 * @see org.eclipse.jface.preference.StringButtonFieldEditor#doFillIntoGrid(Composite
	 *      parent, int numColumns)
	 */
	private void createProjectLocationControls(Composite parent, int numColumns) {
		// Location label
		LocationTypes.PROJECT_LOCATION.label = createLocationLabel(parent,
				"&Location:");
		LocationTypes.PROJECT_LOCATION.label.setEnabled(false);
		// projectLocationLabel = createLocationLabel(parent, "&Location:");
		// projectLocationLabel.setEnabled(false);

		LocationTypes.PROJECT_LOCATION.textComposite = createLocationTextComposite(
				parent, numColumns - 1);
		// projectLocationTextComposite = createLocationTextComposite(parent,
		// numColumns-1);

		// Location text field on its own composite (so we can redraw it -
		// workaround for read-only Texts)
		LocationTypes.PROJECT_LOCATION.text = createLocationText(
				LocationTypes.PROJECT_LOCATION.textComposite, numColumns - 1,
				SWT.READ_ONLY);
		LocationTypes.PROJECT_LOCATION.text.setText(TextProcessor
				.process(getDefaultPathDisplayString()));
		// projectLocationTextField =
		// createLocationText(projectLocationTextComposite, numColumns-1,
		// SWT.READ_ONLY);
		// projectLocationTextField.setText(TextProcessor.process(getDefaultPathDisplayString()));

		// Location browse button
		LocationTypes.PROJECT_LOCATION.button = createLocationBrowseButton(
				parent, LocationTypes.PROJECT_LOCATION);
		LocationTypes.PROJECT_LOCATION.button.setEnabled(false);
		// projectLocationBrowseButton = createLocationBrowseButton(parent,
		// LocationTypes.PROJECT_LOCATION);
		// projectLocationBrowseButton.setEnabled(false);
	}

	/*
	 * @see org.eclipse.ui.internal.ide.dialogs.ProjectContentsLocationArea#
	 * getDefaultPathDisplayString()
	 */
	private String getDefaultPathDisplayString() {
		URI defaultURI = null;
		if (existingProject != null) {
			defaultURI = existingProject.getLocationURI();
		}

		// Handle files specially. Assume a file if there is no project to query
		if (defaultURI == null || defaultURI.getScheme().equals(FILE_SCHEME)) {
			return Platform.getLocation().append(projectName).toOSString();
		}
		return defaultURI.toString();
	}

	/**
	 * @see org.eclipse.jface.preference.FieldEditor#getLabelControl(Composite)
	 */
	private Label createLocationLabel(Composite parent, String text) {
		Label label = new Label(parent, SWT.LEFT);
		label.setFont(parent.getFont());
		label.setText(text);
		return label;
	}

	/**
	 * Create a composite for the location text field. This enables us to
	 * dispose and recreate the location text field so that we switch text type
	 * between read-only and read-write.
	 * 
	 * @param parent
	 *            parent control to create text composite under
	 * @return the new text composite
	 */
	private Composite createLocationTextComposite(Composite parent, int columns) {
		Composite composite = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		layout.numColumns = columns;
		composite.setLayout(layout);
		composite.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		return composite;
	}

	/**
	 * @see org.eclipse.jface.preference.StringFieldEditor#getTextControl(Composite)
	 */
	private Text createLocationText(Composite parent, int horizSpan, int options) {
		final Text textField = new Text(parent, SWT.SINGLE | SWT.BORDER
				| options);
		textField.setFont(parent.getFont());
		textField.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		textField.addKeyListener(new KeyAdapter() {
			/**
			 * @see org.eclipse.swt.events.KeyAdapter#keyReleased(org.eclipse.swt.events.KeyEvent)
			 */
			@Override
			public void keyReleased(KeyEvent e) {
				valueChanged();
			}
		});
		textField.addFocusListener(new FocusAdapter() {
			// Ensure that the value is checked on focus loss in case we
			// missed a keyRelease or user hasn't released key.
			// See https://bugs.eclipse.org/bugs/show_bug.cgi?id=214716
			@Override
			public void focusLost(FocusEvent e) {
				valueChanged();
			}
		});
		// final ModifyListener listener = new ModifyListener() {
		// /**
		// * @see
		// org.eclipse.ui.internal.ide.dialogs.ProjectContentsLocationArea#createUserEntryArea(Composite
		// composite, boolean defaultEnabled)
		// */
		// @Override
		// public void modifyText(ModifyEvent e) {
		// reportError(checkValidLocation(), false);
		// }
		// };
		// textField.addModifyListener(listener);
		// textField.addDisposeListener(new DisposeListener() {
		// @Override
		// public void widgetDisposed(DisposeEvent e) {
		// textField.removeModifyListener(listener);
		// }
		// });

		GridData gd = new GridData();
		gd.horizontalSpan = horizSpan;
		gd.horizontalAlignment = GridData.FILL;
		gd.grabExcessHorizontalSpace = true;
		textField.setLayoutData(gd);

		// TODO: Text Limits?
		// if (textLimit > 0) {// Only set limits above 0 - see SWT spec
		// textField.setTextLimit(textLimit);
		// }
		return textField;
	}

	/**
	 * @see org.eclipse.jface.preference.StringButtonFieldEditor#getChangeControl(Composite
	 *      parent)
	 */
	private Button createLocationBrowseButton(Composite parent,
			final LocationTypes type) {
		Button locationBrowseButton = new Button(parent, SWT.PUSH);
		locationBrowseButton.setText(JFaceResources.getString("openBrowse"));
		locationBrowseButton.setFont(parent.getFont());
		locationBrowseButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent evt) {
				String newValue = handleLocationBrowsePressed(type.text.getText());
				if (newValue != null) {
					setStringValue(newValue, type);
				}
			}
		});
		GridData gd = new GridData();
		gd.horizontalAlignment = GridData.FILL;
		int widthHint = convertHorizontalDLUsToPixels(locationBrowseButton,
				IDialogConstants.BUTTON_WIDTH);
		gd.widthHint = Math.max(widthHint, locationBrowseButton.computeSize(
				SWT.DEFAULT, SWT.DEFAULT, true).x);
		locationBrowseButton.setLayoutData(gd);
		return locationBrowseButton;
	}

	/**
	 * @see org.eclipse.jface.preference.StringFieldEditor#setStringValue(String
	 *      value)
	 */
	void setStringValue(String value, LocationTypes type) {
		if (type.text != null) {
			String val = (value == null) ? "" : value;
			String oldValue = type.text.getText();
			// String oldValue = projectLocationTextField.getText();
			if (!oldValue.equals(val)) {
				type.text.setText(val);
				// projectLocationTextField.setText(val);
				valueChanged();
			}
		}
	}

	/**
	 * @see org.eclipse.jface.preference.DirectoryFieldEditor#changePressed()
	 */
	String handleLocationBrowsePressed(String currPath) {
		File f = new File(currPath);
		if (!f.exists()) {
			f = null;
		}
		File d = getDirectory(f);
		if (d == null) {
			return null;
		}

		return d.getAbsolutePath();
	}

	/**
	 * @see org.eclipse.jface.preference.DirectoryFieldEditor#getDirectory(File
	 *      startingDirectory)
	 */
	private File getDirectory(File startingDirectory) {
		DirectoryDialog fileDialog = new DirectoryDialog(getShell(), SWT.OPEN
				| SWT.SHEET);
		if (startingDirectory != null) {
			fileDialog.setFilterPath(startingDirectory.getPath());
		} else if (filterPath != null) {
			fileDialog.setFilterPath(filterPath.getPath());
		}
		fileDialog.setMessage("Choose a directory for the project contents:");
		String dir = fileDialog.open();
		if (dir != null) {
			dir = dir.trim();
			if (dir.length() > 0) {
				return new File(dir);
			}
		}

		return null;
	}

	void valueChanged() {
		reportError(checkValidLocation(), false);
	}

	private void createCorePathLocationArea(Composite composite) {
		int columns = 4;
		GridLayout layout = new GridLayout();
		layout.verticalSpacing = 15;
		composite.setLayout(layout);

		Group corePathGroup = new Group(composite, SWT.NULL);
		corePathGroup.setText("JPF Core");

		layout = new GridLayout();
		layout.numColumns = columns;
		corePathGroup.setLayout(layout);
		corePathGroup.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		// default button
		fUseDefaultCorePathButton = createUseDefaultButton(corePathGroup,
				columns, LocationTypes.CORE_PATH_LOCATION);

		// label
		LocationTypes.CORE_PATH_LOCATION.label = new Label(corePathGroup,
				SWT.NULL);
		LocationTypes.CORE_PATH_LOCATION.label.setText("JPF core path:");
		LocationTypes.CORE_PATH_LOCATION.label.setEnabled(false);
		// fCorePathLabel = new Label(corePathGroup, SWT.NULL);
		// fCorePathLabel.setText("JPF core path:");
		// fCorePathLabel.setEnabled(false);

		LocationTypes.CORE_PATH_LOCATION.textComposite = createLocationTextComposite(
				corePathGroup, columns - 2);
		// corePathTextComposite = createLocationTextComposite(corePathGroup,
		// columns-2);

		// location text
		LocationTypes.CORE_PATH_LOCATION.text = createLocationText(
				LocationTypes.CORE_PATH_LOCATION.textComposite, columns - 2,
				SWT.READ_ONLY);
		LocationTypes.CORE_PATH_LOCATION.text.setText(defaultCorePath);
		// fCorePathText = createLocationText(corePathTextComposite, columns-2,
		// SWT.READ_ONLY);
		// fCorePathText.setText("");

		// browse button
		LocationTypes.CORE_PATH_LOCATION.button = createLocationBrowseButton(
				corePathGroup, LocationTypes.CORE_PATH_LOCATION);
		LocationTypes.CORE_PATH_LOCATION.button.setEnabled(false);
		// fCorePathBrowseButton = createLocationBrowseButton(corePathGroup,
		// LocationTypes.CORE_PATH_LOCATION);
		// fCorePathBrowseButton.setEnabled(false);
	}

	private Button createUseDefaultButton(Composite composite, int horizSpan,
			final LocationTypes type) {
		final Button button = new Button(composite, SWT.CHECK | SWT.RIGHT);
		button.setText("Use default location");
		button.setSelection(true);
		GridData buttonData = new GridData();
		buttonData.horizontalSpan = horizSpan;
		button.setLayoutData(buttonData);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				boolean defaultSelected = button.getSelection();
				type.label.setEnabled(!defaultSelected);
				type.button.setEnabled(!defaultSelected);
				type.text = recreateProjectTextField(type.text,
						type.textComposite, type, defaultSelected);
				String error = checkValidLocation();
				reportError(
						error,
						error != null
								&& error.equals("Project location directory must be specified"));
			}
		});
		return button;
	}

	private String getCorePathLocation() {
		String text = LocationTypes.CORE_PATH_LOCATION.text.getText();
		// String text = fCorePathText.getText();
		if (text.startsWith(File.separator) || text.startsWith("/")) //$NON-NLS-1$
			text = text.substring(1);
		if (text.endsWith(File.separator) || text.endsWith("/")) //$NON-NLS-1$
			text = text.substring(0, text.length() - 1);
		return text.trim();
	}
	
	private String getProjectPathLocation() {
		return LocationTypes.PROJECT_LOCATION.text.getText();
		// return projectLocationTextField.getText();
	}

	/**
	 * @see org.eclipse.jface.preference.FieldEditor#convertHorizontalDLUsToPixels(Control
	 *      control, int dlus)
	 */
	private int convertHorizontalDLUsToPixels(Button control, int dlus) {
		GC gc = new GC(control);
		gc.setFont(control.getFont());
		int averageWidth = gc.getFontMetrics().getAverageCharWidth();
		gc.dispose();

		double horizontalDialogUnitSize = averageWidth * 0.25;

		return (int) Math.round(dlus * horizontalDialogUnitSize);
	}

	/*
	 * @see org.eclipse.ui.internal.ide.dialogs.ProjectContentsLocationArea#
	 * setExistingProject(IProject existingProject)
	 */
	private void setExistingProject(IProject existingProject) {
		projectName = existingProject.getName();
		this.existingProject = existingProject;
	}

	/*
	 * @see org.eclipse.ui.dialogs.WizardNewProjectCreationPage#validatePage()
	 */
	protected boolean validatePage() {
		IWorkspace workspace = ResourcesPlugin.getWorkspace();

		String projectFieldContents = getProjectNameFieldValue();
		if (projectFieldContents.equals("")) { //$NON-NLS-1$
			setErrorMessage(null);
			setMessage("Project name must be specified");
			return false;
		}

		IStatus nameStatus = workspace.validateName(projectFieldContents,
				IResource.PROJECT);
		if (!nameStatus.isOK()) {
			setErrorMessage(nameStatus.getMessage());
			return false;
		}

		IProject handle = getProjectHandle();
		if (handle.exists()) {
			setErrorMessage("A project with that name already exists in the workspace.");
			return false;
		}

		IProject project = ResourcesPlugin.getWorkspace().getRoot()
				.getProject(projectFieldContents);
		setExistingProject(project);

		String validLocationMessage = checkValidLocation();
		if (validLocationMessage != null) { // there is no destination location
											// given
			setErrorMessage(validLocationMessage);
			return false;
		}

		// String corePathLocation = getCorePathLocation();
		// if (corePathLocation != null && corePathLocation.trim().length() ==
		// 0) {
		// setErrorMessage("Invalid core path location");
		// return false;
		// }
		setErrorMessage(null);
		setMessage(null);
		return true;
	}

	/*
	 * @see org.eclipse.ui.internal.ide.dialogs.ProjectContentsLocationArea#
	 * checkValidLocation()
	 */
	String checkValidLocation() {
		String locationFieldContents = getProjectPathLocation();
		if (locationFieldContents.length() == 0) {
			return "Project location directory must be specified";
		}

		URI newPath = URIUtil.toURI(locationFieldContents);
		if (newPath == null) {
			return "Invalid location path";
		}

		if (existingProject != null) {
			URI projectPath = existingProject.getLocationURI();
			if (projectPath != null && URIUtil.equals(projectPath, newPath)) {
				return "Location is the current location";
			}
		}

		if (!projectDefaultLocationButton.getSelection()) {
			IStatus locationStatus = ResourcesPlugin.getWorkspace()
					.validateProjectLocationURI(existingProject, newPath);

			if (!locationStatus.isOK()) {
				return locationStatus.getMessage();
			}
		}
		
		String corePath = getCorePathLocation();
		if (corePath == null || corePath.length() == 0) {
			return "Core path location must be specified";
		}
		
		if (!pathExists(corePath)) {
			return "Core path location is invalid";
		}

		return null;
	}
	
	private boolean pathExists(String path) {
//		if (path == null)
//			return false;
//		URI uri = URIUtil.toURI(path);
//		if (uri == null)
//			return false;
//		try {
//			IFileStore fileStore = EFS.getStore(uri);
//			return (fileStore != null) && fileStore.fetchInfo().exists();
//		} catch (CoreException e) {
//			return false;
//		}
		
		File file = new File(path);
		if (file.exists()) {
			// check for valid jpf-core
			File jpf_core = new File(file, "/build/RunJPF.jar");
			if (jpf_core.exists()) {
				return true;
			}
		}
		return false;
	}

	/*
	 * @see org.eclipse.ui.dialogs.WizardNewProjectCreationPage#getProjectHandle()
	 */
	private IProject getProjectHandle() {
		return ResourcesPlugin.getWorkspace().getRoot()
				.getProject(getProjectName());
	}

	/*
	 * @see org.eclipse.ui.dialogs.WizardNewProjectCreationPage#getProjectName()
	 */
	private String getProjectName() {
		if (projectNameField == null) {
			return initialProjectFieldValue;
		}

		return getProjectNameFieldValue();
	}

	/*
	 * @see org.eclipse.ui.dialogs.WizardNewProjectCreationPage#getProjectNameFieldValue()
	 */
	private String getProjectNameFieldValue() {
		if (projectNameField == null) {
			return ""; //$NON-NLS-1$
		}

		return projectNameField.getText().trim();
	}

	/*
	 * @see org.eclipse.ui.internal.ide.dialogs.ProjectContentsLocationArea#
	 * updateProjectName(String newName)
	 */
	private void updateProjectName(String newName) {
		projectName = newName;
		if (projectDefaultLocationButton.getSelection()) {
			LocationTypes.PROJECT_LOCATION.text.setText(TextProcessor
					.process(getDefaultPathDisplayString()));
			// projectLocationTextField.setText(TextProcessor.process(getDefaultPathDisplayString()));
		}
	}

	/*
	 * @see org.eclipse.ui.dialogs.WizardNewProjectCreationPage#getErrorReporter()
	 */
	public void reportError(String errorMessage, boolean infoOnly) {
		if (infoOnly) {
			setMessage(errorMessage, IStatus.INFO);
			setErrorMessage(null);
		} else
			setErrorMessage(errorMessage);
		boolean valid = errorMessage == null;
		if (valid) {
			valid = validatePage();
		}

		setPageComplete(valid);
	}

	public boolean performFinish() {
		try {
			new CreateProject(getCorePathLocation(), getProjectPathLocation()
					.toString()).createProject();
		} catch (RuntimeException re) {
			MessageBox box = new MessageBox(getShell(), SWT.ICON_ERROR | SWT.OK);
			box.setText("Invalid path location");
			box.setMessage("One of the provided paths is invalid");
			box.open();
			return false;
		}
		return true;
	}
}
