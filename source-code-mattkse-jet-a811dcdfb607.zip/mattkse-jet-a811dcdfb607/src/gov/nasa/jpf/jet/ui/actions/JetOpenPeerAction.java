package gov.nasa.jpf.jet.ui.actions;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IMember;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.search.IJavaSearchConstants;
import org.eclipse.jdt.core.search.IJavaSearchResultCollector;
import org.eclipse.jdt.core.search.IJavaSearchScope;
import org.eclipse.jdt.core.search.SearchEngine;
import org.eclipse.jdt.internal.core.SourceType;
import org.eclipse.jdt.ui.JavaUI;
import org.eclipse.jdt.ui.actions.SelectionDispatchAction;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IEditorActionDelegate;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchSite;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.texteditor.ITextEditor;

@SuppressWarnings("restriction")
public class JetOpenPeerAction extends SelectionDispatchAction implements
		IEditorActionDelegate, IWorkbenchWindowActionDelegate {

	@Override
	public boolean isEnabled() {
		return true;
	}

	public JetOpenPeerAction() {
		super(PlatformUI.getWorkbench().getActiveWorkbenchWindow()
				.getActivePage().getActivePart().getSite());
	}

	public JetOpenPeerAction(IWorkbenchSite site) {
		super(site);
		setText("[JPF] Open Peer Implementation");
	}

	/**
	 * This method is called when this action is invoked via an in-editor context
	 * menu or its corresponding hotkey
	 */
	@Override
	public void run(IAction action) {
		ITextEditor te = (ITextEditor) PlatformUI.getWorkbench()
				.getActiveWorkbenchWindow().getActivePage().getActiveEditor();
		IFileEditorInput fei = (IFileEditorInput) te.getEditorInput();
		IFile file = fei.getFile();
		ICompilationUnit iCompUnit = JavaCore.createCompilationUnitFrom(file);
		if (iCompUnit == null) {
			System.out.println("Unable to recognize compilation unit!");
			return;
		}
		// IJavaElement selectedElem = null;
		// ITextSelection tsel = (ITextSelection) te.getSelectionProvider()
		// .getSelection();
		// selectedElem = iCompUnit.getElementAt(tsel.getOffset());
		// if (selectedElem instanceof IMethod) {
		// IMethod selectedMethod = (IMethod) selectedElem;
		// if (JdtFlags.isNative(selectedMethod)) {
		IJavaElement packge = iCompUnit.getParent();
		while (!(packge instanceof IPackageFragment)) {
			packge = packge.getParent();
		}
		String packageName = packge.getElementName().replaceAll("[.]", "_");
		String mangled_peer_typename = "JPF_".concat(packageName).concat("_")
				.concat(iCompUnit.getElementName().replace(".java", ""));
		IJavaProject searchScope = iCompUnit.getJavaProject();
		findAndOpenPeer(mangled_peer_typename,
				new IJavaElement[] { searchScope });
	}

	private boolean setStatusLineError() {
		IStatusLineManager statusLineManager = null;
		IWorkbenchPage activePage = PlatformUI.getWorkbench()
				.getActiveWorkbenchWindow().getActivePage();
		if (activePage != null) {
			IWorkbenchPart activePart = activePage.getActivePart();
			if (activePart instanceof IViewPart)
				statusLineManager = ((IViewPart) activePart).getViewSite()
						.getActionBars().getStatusLineManager();
			else if (activePart instanceof IEditorPart)
				statusLineManager = ((IEditorPart) activePart).getEditorSite()
						.getActionBars().getStatusLineManager();
		}
		if (statusLineManager != null) {
			statusLineManager
					.setErrorMessage("JPF: Requested action cannot be performed");
			return true;
		}
		return false;
	}

	private void findAndOpenPeer(String mangled_peer_typename,
			IJavaElement[] scope) {
		try {
			SearchEngine engine = new SearchEngine();
			IJavaSearchScope searchScope = SearchEngine.createJavaSearchScope(
					scope, IJavaSearchScope.SOURCES
							| IJavaSearchScope.REFERENCED_PROJECTS);

			IJavaSearchResultCollector resultCollector = new IJavaSearchResultCollector() {

				int numResults = 0;

				@Override
				public void aboutToStart() {
					// do nothing
				}

				@Override
				public void accept(IResource resource, int start, int end,
						IJavaElement enclosingElement, int accuracy)
						throws CoreException {
					if (enclosingElement instanceof SourceType) {
						JavaUI.openInEditor(enclosingElement);
						numResults++;
						return;
					}
				}

				@Override
				public void done() {
					if (numResults == 0) {
						setStatusLineError();
					}
				}

				@Override
				public IProgressMonitor getProgressMonitor() {
					return null;
				}

			};
			engine.search(ResourcesPlugin.getWorkspace(),
					mangled_peer_typename, IJavaSearchConstants.TYPE,
					IJavaSearchConstants.DECLARATIONS, searchScope,
					resultCollector);
		} catch (JavaModelException e) {
			if (!setStatusLineError()) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * This method is called when this action is invoked via the JET Outline pane
	 */
	@Override
	public void run(IStructuredSelection selection) {
		// get the selected element
		IMember member = (IMember) selection.getFirstElement();

		// find the package name of the class in context
		IJavaElement packge = member.getParent();
		IJavaElement type = null;
		while (!(packge instanceof IPackageFragment)) {
			if (packge instanceof IType) {
				type = packge;
			}
			packge = packge.getParent();
		}
		String packageName = packge.getElementName().replaceAll("[.]", "_");
		String mangled_peer_typename = "JPF_".concat(packageName).concat("_")
				.concat(type.getElementName());

		// get the java project in which this selection is defined
		IJavaProject searchScope = member.getJavaProject();

		findAndOpenPeer(mangled_peer_typename,
				new IJavaElement[] { searchScope });
	}

	@Override
	public void selectionChanged(IAction action, ISelection selection) {
	}

	@Override
	public void dispose() {
	}

	@Override
	public void init(IWorkbenchWindow window) {
	}

	@Override
	public void setActiveEditor(IAction action, IEditorPart targetEditor) {
	}

}
