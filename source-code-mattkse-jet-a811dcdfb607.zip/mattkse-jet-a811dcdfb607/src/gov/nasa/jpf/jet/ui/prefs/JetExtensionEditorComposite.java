//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.jet.ui.prefs;

import gov.nasa.jpf.jet.JetPlugin;
import gov.nasa.jpf.jet.ui.helpers.prefs.filesystem.JetSiteResourceManager;
import gov.nasa.jpf.jet.ui.helpers.prefs.ifaces.JetPropertyChangeListener;

import java.io.IOException;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;

public class JetExtensionEditorComposite extends Composite implements
		JetPropertyChangeListener {

	// UI Controls
	private Button save;
	private Button reload;

	// used to compute layout sizes
	private FontMetrics fontMetrics;

	private JetExtensionsTab jetExtensionsTab;

	private JetSiteResourceManager properties;

	private boolean dirty = false;

	/**
	 * Constructs this composite to hold all of the modeproperty editors.
	 * 
	 * @param parent
	 *            the parent for this composite
	 * @param project
	 *            the java project associated to the modepropertyconfiguration
	 * @param properties
	 *            the modepropertyconfiguration being modified.
	 */
	public JetExtensionEditorComposite(Composite parent,
			JetSiteResourceManager manager) {
		super(parent, SWT.NONE);
		this.properties = manager;
		this.properties.addChangeListener(this);
	}

	public void createContents(Composite parent) {
		initializeDialogUnits(parent);

		GridLayout layout = new GridLayout();
		layout.marginWidth = 0;
		layout.marginHeight = 0;
		this.setLayout(layout);
		this.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));

		createExtensionsTab(parent);

		createSaveReloadButtons(parent);
	}

	private void createExtensionsTab(Composite parent) {
		TabFolder tabFolder = new TabFolder(parent, SWT.NONE);
		tabFolder.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		tabFolder.setLayout(new GridLayout());

		TabItem extensionsTabItem = new TabItem(tabFolder, SWT.NULL);
		jetExtensionsTab = new JetExtensionsTab(tabFolder, properties);
		jetExtensionsTab.createContents(jetExtensionsTab);
		extensionsTabItem.setControl(jetExtensionsTab);
		extensionsTabItem.setText(jetExtensionsTab.getTabName());
	}

	private void createSaveReloadButtons(Composite parent) {
		Composite buttonComp = new Composite(parent, SWT.NULL);
		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		layout.marginWidth = 0;
		layout.marginHeight = 0;
		buttonComp.setLayout(layout);
		buttonComp.setLayoutData(new GridData(SWT.END, SWT.FILL, true, false));

		reload = new Button(buttonComp, SWT.NULL);
		reload.setEnabled(true);
		reload.setText("Reload");
		reload.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				handleButtonReloadPressed();
			}
		});
		reload.setToolTipText("Reloads the properties displayed to those stored "
				+ "in the site.properties file.");
		reload.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		Dialog.applyDialogFont(reload);
		setButtonLayoutData(reload);

		save = new Button(buttonComp, SWT.NULL);
		setSaveButtonEnabled(dirty);
		save.setText("Save");
		save.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				saveProperties();
			}
		});
		save.setToolTipText("Saves the changes made to the site.properties file.");
		save.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		Dialog.applyDialogFont(save);
		setButtonLayoutData(save);
	}

	/**
	 * Initializes the computation of horizontal and vertical dialog units based
	 * on the size of current font.
	 * <p>
	 * This method must be called before <code>setButtonLayoutData</code> is
	 * called.
	 * </p>
	 * 
	 * @param control
	 *            a control from which to obtain the current font
	 */
	protected void initializeDialogUnits(Control control) {
		// Compute and store a font metric
		GC gc = new GC(control);
		gc.setFont(control.getFont());
		fontMetrics = gc.getFontMetrics();
		gc.dispose();
	}

	/**
	 * Sets the <code>GridData</code> on the specified button to be one that is
	 * spaced for the current dialog page units. The method
	 * <code>initializeDialogUnits</code> must be called once before calling
	 * this method for the first time.
	 * 
	 * @param button
	 *            the button to set the <code>GridData</code>
	 * @return the <code>GridData</code> set on the specified button
	 */
	private GridData setButtonLayoutData(Button button) {
		GridData data = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
		int widthHint = Dialog.convertHorizontalDLUsToPixels(fontMetrics,
				IDialogConstants.BUTTON_WIDTH);
		data.widthHint = Math.max(widthHint,
				button.computeSize(SWT.DEFAULT, SWT.DEFAULT, true).x);
		button.setLayoutData(data);
		return data;
	}

	/**
	 * Saves the properties being modified to the configuration file
	 */
	public boolean saveProperties() {
		if (isDirty()) {
			MessageBox box = new MessageBox(getShell(), SWT.ICON_QUESTION
					| SWT.OK | SWT.CANCEL);
			box.setText("Overwrite existing file?");
			box.setMessage("This will overwrite your existing site.properties, if one exists.  "
					+ "If it does not exist, one will be created for you.  Continue?");
			if (box.open() == SWT.OK) {
				try {
					setSaveButtonEnabled(false);
					jetExtensionsTab.save();
					return true;
				} catch (IOException e) {
					JetPlugin.logError("Could not save file.", e);
					box = new MessageBox(getShell(), SWT.ICON_ERROR | SWT.OK);
					box.setText("Error occurred while saving");
					box.setMessage("An I/O Error occurred while saving");
					box.open();
					setSaveButtonEnabled(true);
				}
			}
			return false;
		}
		return true;
	}

	/**
	 * Reverts this editor show the properties contained in the file.
	 * 
	 */
	public void handleButtonReloadPressed() {
		setSaveButtonEnabled(false);
		jetExtensionsTab.reloadExtensions();
	}

	private void setSaveButtonEnabled(boolean enabled) {
		save.setEnabled(enabled);
	}

	/**
	 * Executed when a change to the properties being modified occurs Enables
	 * the save and revert buttons.
	 * 
	 * @see gov.nasa.jpf.jet.ui.helpers.prefs.ifaces.JetPropertyChangeListener#changeOccurred
	 *      ()
	 */
	@Override
	public void changeOccurred() {
		dirty = true;
		if (save != null) {
			setSaveButtonEnabled(true);
		}
	}

	/*
	 * True if there are changes to be saved to the config file.
	 */
	private boolean isDirty() {
		return save.isEnabled();
	}

	public JetSiteResourceManager getExtensionManager() {
		return properties;
	}
}
