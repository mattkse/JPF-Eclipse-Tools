//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.jet.ui.prefs;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import gov.nasa.jpf.jet.JetPlugin;
import gov.nasa.jpf.jet.ui.JetColors;
import gov.nasa.jpf.jet.ui.helpers.prefs.filesystem.JetSiteResourceManager;
import gov.nasa.jpf.jet.ui.helpers.prefs.ifaces.JetDuplicateExtChecker;
import gov.nasa.jpf.jet.ui.helpers.prefs.models.JPFExtension;
import gov.nasa.jpf.jet.ui.helpers.prefs.providers.JPFExtensionContentProvider;
import gov.nasa.jpf.jet.ui.helpers.prefs.providers.JPFExtensionEditingSupport;

import org.eclipse.core.filesystem.EFS;
import org.eclipse.core.filesystem.IFileStore;
import org.eclipse.core.filesystem.URIUtil;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.layout.TableColumnLayout;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.viewers.CellLabelProvider;
import org.eclipse.jface.viewers.ColumnViewerToolTipSupport;
import org.eclipse.jface.viewers.ColumnWeightData;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.jface.window.ToolTip;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontMetrics;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

public class JetExtensionsTab extends Composite {

	private static final String JPF_CORE_EXT_NAME = "jpf-core";

	public static final int NAME_INDEX = 0, ID_INCLUDED = 0;
	public static final int LOCATION_INDEX = 1, ID_EXCLUDED = 1;

	static final Image imageBlank = JetPlugin.getImageDescriptor(
			"icons/prefs/blank.png").createImage();
	static final Image imageError = JFaceResources
			.getImage(Dialog.DLG_IMG_MESSAGE_ERROR);
	static final Image imageWarning = JFaceResources
			.getImage(Dialog.DLG_IMG_MESSAGE_WARNING);

	class NameLabelProvider extends CellLabelProvider {
		@Override
		public String getToolTipText(Object element) {
			return null;
		}

		@Override
		public Point getToolTipShift(Object object) {
			return new Point(5, 5);
		}

		@Override
		public int getToolTipDisplayDelayTime(Object object) {
			return 0;
		}

		@Override
		public int getToolTipTimeDisplayed(Object object) {
			return 15000;
		}

		@Override
		public void update(ViewerCell cell) {
			JPFExtension ext = (JPFExtension) cell.getElement();
			cell.setText(ext.getName());
//TODO
//			cell.setImage(imageBlank);
		}

	}

	class LocationLabelProvider extends CellLabelProvider {
		@Override
		public String getToolTipText(Object element) {
			JPFExtension ext = (JPFExtension) element;
			return ext.getLocation();
		}

		@Override
		public Point getToolTipShift(Object object) {
			return new Point(5, 5);
		}

		@Override
		public int getToolTipDisplayDelayTime(Object object) {
			return 0;
		}

		@Override
		public int getToolTipTimeDisplayed(Object object) {
			return 15000;
		}

		@Override
		public void update(ViewerCell cell) {
			JPFExtension ext = (JPFExtension) cell.getElement();
			String extPath = ext.getLocation();
			cell.setText(extPath);
			Image image = null;
			
			if (!pathExists(extPath)) {
				image = (ext.getName().equals(JPF_CORE_EXT_NAME)) ? imageError
						: imageWarning;
			}
			cell.setImage(image);
		}

		private boolean pathExists(String path) {
			if (path == null)
				return false;
			URI uri = URIUtil.toURI(path);
			if (uri == null)
				return false;
			try {
				IFileStore fileStore = EFS.getStore(uri);
				return (fileStore != null) && fileStore.fetchInfo().exists();
			} catch (CoreException e) {
				return false;
			}
		}

	}

	private class ViewerArea {

		Collection<JPFExtension> fElements = new ArrayList<JPFExtension>();

		// UI Controls
		private Button buttonNew;
		private Button buttonEdit;
		private Button buttonRemove;
		private Button buttonUp;
		private Button buttonDown;
		TableViewer viewer;

		int id;

		public ViewerArea(int id) {
			this.id = id;
		}

		public void createContents(Composite parent) {
			Composite tableComposite = new Composite(parent, SWT.NONE);
			GridData data = new GridData(SWT.FILL, SWT.FILL, true, true);
			data.grabExcessHorizontalSpace = true;
			data.grabExcessVerticalSpace = true;
			tableComposite.setLayoutData(data);

			viewer = new TableViewer(tableComposite, SWT.MULTI | SWT.H_SCROLL
					| SWT.V_SCROLL | SWT.FULL_SELECTION | SWT.BORDER
					| SWT.VIRTUAL);
			createTable(tableComposite, viewer);

			createButtons(parent);
		}

		private void createTable(Composite parent, final TableViewer tblViewer) {
			createColumns(parent, tblViewer);

			tblViewer.setUseHashlookup(true);
			tblViewer.setContentProvider(new JPFExtensionContentProvider());

			tblViewer.addDoubleClickListener(new IDoubleClickListener() {
				@Override
				public void doubleClick(DoubleClickEvent event) {
					if (tblViewer.getTable().getSelectionCount() == 1)
						handleButtonEditPressed();
				}
			});
			tblViewer
					.addSelectionChangedListener(new ISelectionChangedListener() {
						@Override
						public void selectionChanged(SelectionChangedEvent event) {
							updateEnabledState();
						}
					});
		}

		// This will create the columns for the table
		private void createColumns(Composite parent, final TableViewer tblViewer) {
			Table table = tblViewer.getTable();
			table.addFocusListener(new FocusListener() {

				@Override
				public void focusLost(FocusEvent e) {
					// do nothing
				}

				@Override
				public void focusGained(FocusEvent e) {
					if (id == ID_INCLUDED) {
						buttonExclude.setEnabled(viewer.getTable()
								.getSelectionCount() > 0
								&& canRemoveSelection());
						buttonInclude.setEnabled(false);
					} else {
						buttonInclude.setEnabled(viewer.getTable()
								.getSelectionCount() > 0);
						buttonExclude.setEnabled(false);
					}
				}
			});
			table.addSelectionListener(new SelectionListener() {

				@Override
				public void widgetSelected(SelectionEvent e) {
					if (id == ID_INCLUDED) {
						buttonExclude.setEnabled(canRemoveSelection());
					} else {
						buttonInclude.setEnabled(true);
					}
					updateEnabledState();
				}

				@Override
				public void widgetDefaultSelected(SelectionEvent e) {
					updateEnabledState();
				}
			});

			ColumnViewerToolTipSupport
					.enableFor(tblViewer, ToolTip.NO_RECREATE);

			TableColumnLayout tableLayout = new TableColumnLayout();
			parent.setLayout(tableLayout);

			TableViewerColumn columnName = new TableViewerColumn(tblViewer,
					SWT.NONE);
			columnName.setLabelProvider(new NameLabelProvider());
			TableColumn column = columnName.getColumn();
			column.setText("Name");
			column.setResizable(true);
			column.setMoveable(true);
			tableLayout.setColumnData(column, new ColumnWeightData(150));
			columnName.setEditingSupport(new JPFExtensionEditingSupport(
					tblViewer, NAME_INDEX, properties.getChangeListeners(),
					duplicateChecker));

			TableViewerColumn columnLocation = new TableViewerColumn(tblViewer,
					SWT.NONE);
			columnLocation.setLabelProvider(new LocationLabelProvider());
			column = columnLocation.getColumn();
			column.setText("Location");
			column.setResizable(true);
			column.setMoveable(true);
			tableLayout.setColumnData(column, new ColumnWeightData(280));
			columnLocation.setEditingSupport(new JPFExtensionEditingSupport(
					tblViewer, LOCATION_INDEX, properties.getChangeListeners(),
					duplicateChecker));

			table.setHeaderVisible(true);
			table.setLinesVisible(true);
			table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		}

		/**
		 * Creates the add/edit/remove buttons
		 * 
		 * @param parent
		 *            the widget parent
		 */
		private void createButtons(Composite parent) {
			Font font = parent.getFont();
			Composite groupComponent = new Composite(parent, SWT.NULL);
			GridLayout groupLayout = new GridLayout();
			groupLayout.marginWidth = 0;
			groupLayout.marginHeight = 0;
			groupComponent.setLayout(groupLayout);
			GridData data = new GridData();
			data.verticalAlignment = GridData.FILL;
			data.horizontalAlignment = GridData.FILL;
			groupComponent.setLayoutData(data);
			groupComponent.setFont(font);

			buttonNew = new Button(groupComponent, SWT.PUSH);
			buttonNew.setText("New...");
			buttonNew.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					handleButtonAddPressed();
				}
			});
			buttonNew.setFont(font);
			setButtonLayoutData(buttonNew);

			buttonEdit = new Button(groupComponent, SWT.PUSH);
			buttonEdit.setText("Edit...");
			buttonEdit.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					handleButtonEditPressed();
				}
			});
			buttonEdit.setFont(font);
			setButtonLayoutData(buttonEdit);

			buttonRemove = new Button(groupComponent, SWT.PUSH);
			buttonRemove.setText("Remove");
			buttonRemove.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					handleButtonRemovePressed();
				}
			});
			buttonRemove.setFont(font);
			setButtonLayoutData(buttonRemove);

			Label label = new Label(groupComponent, SWT.SEPARATOR
					| SWT.HORIZONTAL);
			label.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true, false));

			buttonUp = new Button(groupComponent, SWT.PUSH);
			buttonUp.setText("Up");
			buttonUp.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					handleButtonUpPressed();
				}
			});
			buttonUp.setFont(font);
			setButtonLayoutData(buttonUp);

			buttonDown = new Button(groupComponent, SWT.PUSH);
			buttonDown.setText("Down");
			buttonDown.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					handleButtonDownPressed();
				}
			});
			buttonDown.setFont(font);
			setButtonLayoutData(buttonDown);

			updateEnabledState();
		}

		/**
		 * Opens a dialog for creating a new variable.
		 */
		void handleButtonAddPressed() {
			JetExtensionLocationDialog dialog = openExtensionDialog(null, null,
					JetExtensionLocationDialog.NEW_EXTENSION);
			if (dialog == null) {
				return;
			}

			String newVariableName = dialog.getVariableName();
			String newVariableValue = dialog.getVariableValue().replace('\\',
					'/');

			fElements.add(new JPFExtension(newVariableName, newVariableValue));
			updateViewer(true);
		}

		/**
		 * Opens a dialog for editing an existing variable.
		 * 
		 * @see PathVariableDialog
		 */
		void handleButtonEditPressed() {
			// retrieves the name and value for the currently selected variable
			TableItem item = viewer.getTable().getItem(
					viewer.getTable().getSelectionIndex());
			JPFExtension ext = (JPFExtension) item.getData();
			String currExtName = ext.getName();
			String currExtLocation = ext.getLocation();

			int ext_type = (canRemoveSelection()) ? JetExtensionLocationDialog.FULLY_EDITABLE_EXTENSION
					: JetExtensionLocationDialog.VALUE_ONLY_EXTENSION;

			JetExtensionLocationDialog dialog = openExtensionDialog(
					currExtName, currExtLocation, ext_type);
			if (dialog == null) {
				return;
			}

			String newVariableName = dialog.getVariableName();
			String newVariableLocation = dialog.getVariableValue().replace(
					'\\', '/');

			ext.setName(newVariableName);
			ext.setLocation(newVariableLocation);

			updateViewer(true);
		}

		boolean canRemoveSelection() {
			int[] selectedIndices = viewer.getTable().getSelectionIndices();
			for (int i = 0; i < selectedIndices.length; i++) {
				TableItem selectedItem = viewer.getTable().getItem(
						selectedIndices[i]);
				String extName = ((JPFExtension) selectedItem.getData())
						.getName();
				if (isBuiltInExtension(extName))
					return false;
			}
			return true;
		}

		/**
		 * @param extName
		 *            the variable name to test
		 */
		private boolean isBuiltInExtension(String extName) {
			return extName.equals(JPF_CORE_EXT_NAME);
		}

		private JetExtensionLocationDialog openExtensionDialog(String name,
				String value, int type) {
			// constructs a dialog for editing the variable's current name and
			// value
			JetExtensionLocationDialog dialog = new JetExtensionLocationDialog(
					getShell(), type, getNamesInUse());

			if (name != null) {
				dialog.setExtensionName(name);
				dialog.setExtensionLocation(value);
			}

			dialog.setResource(currentResource);

			// opens the dialog
			if (dialog.open() == Window.CANCEL) {
				return null;
			}
			return dialog;
		}

		private Collection<String> getNamesInUse() {
			Collection<String> names = new HashSet<String>();
			for (JPFExtension ext : viewerInclude.fElements) {
				names.add(ext.getName());
			}
			for (JPFExtension ext : viewerExclude.fElements) {
				names.add(ext.getName());
			}
			return names;
		}

		/**
		 * Removes the currently selected variables.
		 */
		void handleButtonRemovePressed() {
			for (TableItem item : viewer.getTable().getSelection()) {
				JPFExtension ext = ((JPFExtension) item.getData());
				fElements.remove(ext);
			}
			buttonInclude.setEnabled(false);
			buttonExclude.setEnabled(false);
			updateViewer(true);
		}

		void handleButtonUpPressed() {
			JPFExtension ext = (JPFExtension) ((IStructuredSelection) viewer
					.getSelection()).getFirstElement();
			JPFExtension[] extensions = new JPFExtension[fElements.size()];
			fElements.toArray(extensions);

			for (int i = 0; i < extensions.length; i++) {
				if (extensions[i] == ext) {
					// Move the item as long as it's not already at the top of
					// the list
					if (i > 0) {
						ext = extensions[i - 1];
						extensions[i - 1] = extensions[i];
						extensions[i] = ext;
					}
				}
			}
			updatePositions(extensions);
		}

		void handleButtonDownPressed() {
			JPFExtension ext = (JPFExtension) ((IStructuredSelection) viewer
					.getSelection()).getFirstElement();
			JPFExtension[] extensions = new JPFExtension[fElements.size()];
			fElements.toArray(extensions);

			for (int i = 0; i < extensions.length; i++) {
				if (extensions[i] == ext) {
					// Move the item as long as it's not already at the bottom
					// of the list
					if (i < (extensions.length - 1)) {
						ext = extensions[i + 1];
						extensions[i + 1] = extensions[i];
						extensions[i] = ext;
					}
				}
			}
			updatePositions(extensions);
		}

		private void updatePositions(JPFExtension[] extensions) {
			boolean dirty = Arrays.equals(fElements.toArray(), extensions);
			fElements.clear();
			fElements.addAll(Arrays.asList(extensions));
			updateViewer(dirty);
		}

		void updateViewer(boolean setDirty) {
			viewer.setInput(fElements);

			if (setDirty) {
				properties.setDirty(true);
			}

			updateWidgetState();
		}

		/**
		 * Updates the widget's current state: refreshes the table with the
		 * current defined variables, selects the item corresponding to the
		 * given variable (selects the first item if <code>null</code> is
		 * provided) and updates the enabled state for the Add/Remove/Edit
		 * buttons.
		 * 
		 */
		private void updateWidgetState() {
			refresh();
			updateEnabledState();
		}

		/**
		 * Refreshes the contents of this tab.
		 */
		public void refresh() {
			viewer.refresh();
			repackColumns(viewer);
		}

		/**
		 * Repacks all of the columns in the table. This needs to be called from
		 * the SWT Thread.
		 */
		void repackColumns(TableViewer tblViewer) {
			for (TableColumn c : tblViewer.getTable().getColumns()) {
				c.pack();
			}
		}

		/**
		 * Updates button enabled state, depending on the number of currently
		 * selected variables in the table.
		 */
		void updateEnabledState() {
			Table table = viewer.getTable();
			int itemsSelectedCount = table.getSelectionCount();
			boolean oneItem = itemsSelectedCount == 1;
			boolean atLeastOneItem = itemsSelectedCount > 0;
			boolean canRemove = canRemoveSelection();
			boolean upOverride = true;
			buttonEdit.setEnabled(oneItem);
			buttonRemove.setEnabled(atLeastOneItem && canRemove);
			if (!atLeastOneItem) { // no items selected
				buttonUp.setEnabled(false);
				buttonDown.setEnabled(false);
			} else { // at least one item selected
				if (canRemove) {

					// hack to avoid up-button when one below jpf-core
					if (id == ID_INCLUDED) {
						int[] selectedIndices = viewer.getTable()
								.getSelectionIndices();
						for (int i = 0; i < selectedIndices.length; i++) {
							TableItem selectedItem = viewer.getTable().getItem(
									selectedIndices[i] - 1);
							String extName = ((JPFExtension) selectedItem
									.getData()).getName();
							if (extName.equals("jpf-core")) {
								upOverride = false;
								break;
							}
						}
					}

					@SuppressWarnings("unchecked")
					Collection<JPFExtension> input = (Collection<JPFExtension>) viewer
							.getInput();
					if (input.size() != itemsSelectedCount) { // some items
																// aren't
																// selected
						if (oneItem) { // exactly one item selected
							int index = table.getSelectionIndex();
							if (index == 0) {
								buttonUp.setEnabled(false);
								buttonDown.setEnabled(true);
							} else if (index == fElements.size() - 1) {
								buttonUp.setEnabled(true && upOverride);
								buttonDown.setEnabled(false);
							} else {
								buttonUp.setEnabled(true && upOverride);
								buttonDown.setEnabled(true);
							}
						} else { // more than one item selected
							buttonUp.setEnabled(true && upOverride);
							buttonDown.setEnabled(true);
						}
					} else { // all items are selected
						buttonUp.setEnabled(false);
						buttonDown.setEnabled(false);
					}
				} else { // can't remove selection
					buttonUp.setEnabled(false);
					buttonDown.setEnabled(false);
				}
			}
		}

	}

	Button buttonInclude;
	Button buttonExclude;

	private ViewerArea viewerInclude = new ViewerArea(ID_INCLUDED);
	private ViewerArea viewerExclude = new ViewerArea(ID_EXCLUDED);

	private JetDuplicateExtChecker duplicateChecker = new JetDuplicateExtChecker() {

		@Override
		public boolean isDuplicate(String value) {
			for (JPFExtension ext : viewerInclude.fElements) {
				if (value.equals(ext.getName())) {
					return true;
				}
			}
			for (JPFExtension ext : viewerExclude.fElements) {
				if (value.equals(ext.getName())) {
					return true;
				}
			}
			return false;
		}
	};

	private JetSiteResourceManager properties;

	// current project for which the variables are being edited.
	// If null, the workspace variables are being edited instead.
	private IResource currentResource = null;

	// used to compute layout sizes
	private FontMetrics fontMetrics;

	/**
	 * Constructs this tab.
	 * 
	 * @param parent
	 *            the parent composite for this tab
	 * @param properties
	 *            the modepropertyconfiguration being modified
	 */
	public JetExtensionsTab(Composite parent, JetSiteResourceManager properties) {
		super(parent, SWT.NULL);
		this.properties = properties;
	}

	public void createContents(Composite parent) {
		initializeDialogUnits(parent);
		
		GridLayout layout = new GridLayout();
		// layout.numColumns = 2;
		layout.marginWidth = 0;
		layout.marginHeight = 0;
		setLayout(layout);
		GridData data = new GridData(SWT.FILL, SWT.FILL, true, true);
		this.setLayoutData(data);

		Label topLabel = new Label(parent, SWT.WRAP);
		topLabel.setText("The site.properties file tells JPF at startup time where to look for installed projects, so that it can add classpaths accordingly.");
		data = new GridData();
		data.horizontalAlignment = GridData.FILL;
		data.horizontalSpan = 2;
		topLabel.setLayoutData(data);
		topLabel.setFont(parent.getFont());

		createIncludedArea(parent);

		createdIncludedExcludedButtons(parent);

		createExcludedArea(parent);

		// Get the content for the viewer, setInput will call getElements in the
		// contentProvider
		reloadExtensions();
		
		System.out.println("reload extensions fired");
		
		parent.addListener(SWT.Paint, new Listener() {
			
			@Override
			public void handleEvent(Event event) {
				// TODO Auto-generated method stub
				viewerExclude.updateViewer(false);
				viewerInclude.updateViewer(false);
			}
		});
	}

	private void createIncludedArea(Composite parent) {
		Composite includedComposite = new Composite(parent, SWT.BORDER);
//		includedComposite.setBackground(JetColors.pink);

		GridLayout layout = new GridLayout();
		layout.numColumns = 2; 
		layout.marginWidth = 0;
		layout.marginHeight = 0;
		includedComposite.setLayout(layout);

		GridData data = new GridData(SWT.FILL, SWT.FILL, true, true);
		includedComposite.setLayoutData(data);

		Label label = new Label(includedComposite, SWT.LEFT | SWT.BORDER);
		label.setText(" Included Extensions:");
		data = new GridData();
		data.horizontalAlignment = GridData.FILL;
		data.horizontalSpan = 2;
		label.setLayoutData(data);
		label.setFont(includedComposite.getFont());

		viewerInclude.createContents(includedComposite);
	}

	private void createdIncludedExcludedButtons(Composite parent) {
		Composite composite = new Composite(parent, SWT.NULL);
//		composite.setBackground(JetColors.teal);
		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		layout.marginWidth = 0;
		layout.marginHeight = 0;
		composite.setLayout(layout);
		GridData data = new GridData(SWT.CENTER, SWT.CENTER, false, false);
		composite.setLayoutData(data);

		buttonInclude = new Button(composite, SWT.PUSH);
		buttonInclude.setText("^^  Include");
		buttonInclude.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				handleButtonIncludePressed();
			}
		});
		buttonInclude.setEnabled(false);
		buttonInclude.setFont(parent.getFont());
		setButtonLayoutData(buttonInclude);

		buttonExclude = new Button(composite, SWT.PUSH);
		buttonExclude.setText("Exclude  v v");
		buttonExclude.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				handleButtonExcludePressed();
			}
		});
		buttonExclude.setEnabled(false);
		buttonExclude.setFont(parent.getFont());
		setButtonLayoutData(buttonExclude);
	}

	private void createExcludedArea(Composite parent) {
		Composite compositeExcluded = new Composite(parent, SWT.BORDER);

		GridLayout layout = new GridLayout();
		layout.numColumns = 2;
		layout.marginWidth = 0;
		layout.marginHeight = 0;
		compositeExcluded.setLayout(layout);

		GridData data = new GridData(SWT.FILL, SWT.FILL, true, true);
		compositeExcluded.setLayoutData(data);

		Label label = new Label(compositeExcluded, SWT.LEFT | SWT.BORDER);
		label.setText(" Excluded Extensions:");
		data = new GridData();
		data.horizontalAlignment = GridData.FILL;
		data.horizontalSpan = 2;
		label.setLayoutData(data);
		label.setFont(compositeExcluded.getFont());

		viewerExclude.createContents(compositeExcluded);
	}

	private void handleButtonIncludePressed() {
		transferElements(viewerExclude, viewerInclude);
		buttonInclude.setEnabled(false);
	}

	private void handleButtonExcludePressed() {
		transferElements(viewerInclude, viewerExclude);
		buttonExclude.setEnabled(false);
	}

	private void transferElements(ViewerArea sourceViewer, ViewerArea destViewer) {
		for (TableItem item : sourceViewer.viewer.getTable().getSelection()) {
			JPFExtension ext = ((JPFExtension) item.getData());
			sourceViewer.fElements.remove(ext);
			destViewer.fElements.add(ext);
		}
		sourceViewer.updateViewer(true);
		destViewer.updateViewer(true);
	}

	/**
	 * The name to be displayed on the User Defined Properties tab.
	 * 
	 * @return the name displayed
	 */
	public String getTabName() {
		return "JPF Extensions";
	}

	/**
	 * Initializes the computation of horizontal and vertical dialog units based
	 * on the size of current font.
	 * <p>
	 * This method must be called before <code>setButtonLayoutData</code> is
	 * called.
	 * </p>
	 * 
	 * @param control
	 *            a control from which to obtain the current font
	 */
	protected void initializeDialogUnits(Control control) {
		// Compute and store a font metric
		GC gc = new GC(control);
		gc.setFont(control.getFont());
		fontMetrics = gc.getFontMetrics();
		gc.dispose();
	}

	/**
	 * Sets the <code>GridData</code> on the specified button to be one that is
	 * spaced for the current dialog page units. The method
	 * <code>initializeDialogUnits</code> must be called once before calling
	 * this method for the first time.
	 * 
	 * @param button
	 *            the button to set the <code>GridData</code>
	 * @return the <code>GridData</code> set on the specified button
	 */
	private GridData setButtonLayoutData(Button button) {
		GridData data = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
		int widthHint = Dialog.convertHorizontalDLUsToPixels(fontMetrics,
				IDialogConstants.BUTTON_WIDTH);
		data.widthHint = Math.max(widthHint,
				button.computeSize(SWT.DEFAULT, SWT.DEFAULT, true).x);
		button.setLayoutData(data);
		return data;
	}

	/**
	 * @param resource
	 */
	public void setResource(IResource resource) {
		currentResource = resource;
	}

	public void reloadExtensions() {
		properties
				.getFromFile(viewerInclude.fElements, viewerExclude.fElements);
		viewerInclude.updateViewer(false);
		viewerExclude.updateViewer(false);
	}

	public void save() throws IOException {
		properties.save(viewerInclude.fElements, viewerExclude.fElements);
	}

}
