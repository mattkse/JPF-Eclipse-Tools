//
// Copyright (C) 2010 United States Government as represented by the
// Administrator of the National Aeronautics and Space Administration
// (NASA).  All Rights Reserved.
//
// This software is distributed under the NASA Open Source Agreement
// (NOSA), version 1.3.  The NOSA has been approved by the Open Source
// Initiative.  See the file NOSA-1.3-JPF at the top of the distribution
// directory tree for the complete NOSA document.
//
// THE SUBJECT SOFTWARE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY OF ANY
// KIND, EITHER EXPRESSED, IMPLIED, OR STATUTORY, INCLUDING, BUT NOT
// LIMITED TO, ANY WARRANTY THAT THE SUBJECT SOFTWARE WILL CONFORM TO
// SPECIFICATIONS, ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
// A PARTICULAR PURPOSE, OR FREEDOM FROM INFRINGEMENT, ANY WARRANTY THAT
// THE SUBJECT SOFTWARE WILL BE ERROR FREE, OR ANY WARRANTY THAT
// DOCUMENTATION, IF PROVIDED, WILL CONFORM TO THE SUBJECT SOFTWARE.
//

package gov.nasa.jpf.jet.ui.prefs;

import gov.nasa.jpf.jet.JetPlugin;

import org.eclipse.jface.preference.FileFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Button;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

public class JetPreferencePage extends FieldEditorPreferencePage implements
		IWorkbenchPreferencePage {

	private FileFieldEditor siteEditor;

	public static final String SITE_PROPERTIES_PATH = "jpf.site_properties_path";

	public JetPreferencePage() {
		super(GRID);
		setPreferenceStore(JetPlugin.getDefault().getPreferenceStore());
		setDescription("Set the properties for JPF");
	}

	@Override
	protected void createFieldEditors() {
		siteEditor = new FileFieldEditor(SITE_PROPERTIES_PATH,
				"Path to site.properties", getFieldEditorParent());
		Button button = new Button(getFieldEditorParent(), SWT.PUSH);
		button.setText("Configure...");
		button.addSelectionListener(new SelectionListener() {

			@Override
			public void widgetSelected(SelectionEvent e) {
				openConfigWindow();
			}

			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				// do nothing
			}
		});

		addField(siteEditor);
	}

	@Override
	public void init(IWorkbench workbench) {
		// do nothing
	}

	private void openConfigWindow() {
		JetSiteConfigDialog dialog = new JetSiteConfigDialog(getShell());
		dialog.setSitePath(siteEditor.getStringValue());
		dialog.open();
	}

}
