package gov.nasa.jpf.jet.ui.views;

import java.util.Vector;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.ListenerList;
import org.eclipse.jdt.core.ElementChangedEvent;
import org.eclipse.jdt.core.IClassFile;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IElementChangedListener;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaElementDelta;
import org.eclipse.jdt.core.IParent;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.ITypeRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.ui.IContextMenuConstants;
import org.eclipse.jdt.ui.JavaElementLabels;
import org.eclipse.jdt.ui.JavaUI;
import org.eclipse.jdt.ui.ProblemsLabelDecorator.ProblemsLabelChangedEvent;
import org.eclipse.jdt.ui.actions.CCPActionGroup;
import org.eclipse.jdt.ui.actions.GenerateActionGroup;
import org.eclipse.jdt.ui.actions.JavaSearchActionGroup;
import org.eclipse.jdt.ui.actions.OpenViewActionGroup;
import org.eclipse.jdt.ui.actions.RefactorActionGroup;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IMenuListener;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.viewers.IBaseLabelProvider;
import org.eclipse.jface.viewers.IPostSelectionProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProviderChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.actions.ActionContext;
import org.eclipse.ui.actions.ActionGroup;
import org.eclipse.ui.handlers.IHandlerService;
import org.eclipse.ui.model.IWorkbenchAdapter;
import org.eclipse.ui.model.WorkbenchAdapter;
import org.eclipse.ui.navigator.ICommonMenuConstants;
import org.eclipse.ui.part.IPageSite;
import org.eclipse.ui.part.Page;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.views.contentoutline.IContentOutlinePage;

import org.eclipse.jdt.internal.ui.viewsupport.AppearanceAwareLabelProvider;
import org.eclipse.jdt.internal.ui.viewsupport.DecoratingJavaLabelProvider;

public class JetOutlinePage extends Page implements IContentOutlinePage, IPostSelectionProvider {
	
	static Object[] NO_CHILDREN= new Object[0];
	
	/**
	 * The element change listener of the java outline viewer.
	 * @see IElementChangedListener
	 */
	protected class ElementChangedListener implements IElementChangedListener {

		public void elementChanged(final ElementChangedEvent e) {

			if (getControl() == null)
				return;

			Display d= getControl().getDisplay();
			if (d != null) {
				d.asyncExec(new Runnable() {
					public void run() {
						ICompilationUnit cu= (ICompilationUnit) fInput;
						IJavaElement base= cu;
						if (fTopLevelTypeOnly) {
							base= cu.findPrimaryType();
							if (base == null) {
								if (fOutlineViewer != null)
									fOutlineViewer.refresh(true);
								return;
							}
						}
						IJavaElementDelta delta= findElement(base, e.getDelta());
						if (delta != null && fOutlineViewer != null) {
							fOutlineViewer.reconcile(delta);
						}
					}
				});
			}
		}

		private boolean isPossibleStructuralChange(IJavaElementDelta cuDelta) {
			if (cuDelta.getKind() != IJavaElementDelta.CHANGED) {
				return true; // add or remove
			}
			int flags= cuDelta.getFlags();
			if ((flags & IJavaElementDelta.F_CHILDREN) != 0) {
				return true;
			}
			return (flags & (IJavaElementDelta.F_CONTENT | IJavaElementDelta.F_FINE_GRAINED)) == IJavaElementDelta.F_CONTENT;
		}

		protected IJavaElementDelta findElement(IJavaElement unit, IJavaElementDelta delta) {

			if (delta == null || unit == null)
				return null;

			IJavaElement element= delta.getElement();

			if (unit.equals(element)) {
				if (isPossibleStructuralChange(delta)) {
					return delta;
				}
				return null;
			}


			if (element.getElementType() > IJavaElement.CLASS_FILE)
				return null;

			IJavaElementDelta[] children= delta.getAffectedChildren();
			if (children == null || children.length == 0)
				return null;

			for (int i= 0; i < children.length; i++) {
				IJavaElementDelta d= findElement(unit, children[i]);
				if (d != null)
					return d;
			}

			return null;
		}
	}
	
	static class NoClassElement extends WorkbenchAdapter implements IAdaptable {
		/*
		 * @see java.lang.Object#toString()
		 */
		public String toString() {
			return "Top level type not defined";
		}

		/*
		 * @see org.eclipse.core.runtime.IAdaptable#getAdapter(Class)
		 */
		public Object getAdapter(Class clas) {
			if (clas == IWorkbenchAdapter.class)
				return this;
			return null;
		}
	}
	
	/**
	 * Content provider for the children of an ICompilationUnit or
	 * an IClassFile
	 * @see ITreeContentProvider
	 */
	protected class ChildrenProvider implements ITreeContentProvider {

		private Object[] NO_CLASS= new Object[] {new NoClassElement()};
		private ElementChangedListener fListener;

		protected boolean matches(IJavaElement element) {
			if (element.getElementType() == IJavaElement.METHOD) {
				String name= element.getElementName();
				return (name != null && name.indexOf('<') >= 0);
			}
			return false;
		}

		protected IJavaElement[] filter(IJavaElement[] children) {
			boolean initializers= false;
			for (int i= 0; i < children.length; i++) {
				if (matches(children[i])) {
					initializers= true;
					break;
				}
			}

			if (!initializers)
				return children;

			Vector v= new Vector();
			for (int i= 0; i < children.length; i++) {
				if (matches(children[i]))
					continue;
				v.addElement(children[i]);
			}

			IJavaElement[] result= new IJavaElement[v.size()];
			v.copyInto(result);
			return result;
		}

		public Object[] getChildren(Object parent) {
			if (parent instanceof IParent) {
				IParent c= (IParent) parent;
				try {
					return filter(c.getChildren());
				} catch (JavaModelException x) {
					x.printStackTrace();
				}
			}
			return NO_CHILDREN;
		}

		public Object[] getElements(Object parent) {
			if (fTopLevelTypeOnly) {
				if (parent instanceof ITypeRoot) {
					try {
						IType type= ((ITypeRoot) parent).findPrimaryType();
						return type != null ? type.getChildren() : NO_CLASS;
					} catch (JavaModelException e) {
						e.printStackTrace();
					}
				}
			}
			return getChildren(parent);
		}

		public Object getParent(Object child) {
			if (child instanceof IJavaElement) {
				IJavaElement e= (IJavaElement) child;
				return e.getParent();
			}
			return null;
		}

		public boolean hasChildren(Object parent) {
			if (parent instanceof IParent) {
				IParent c= (IParent) parent;
				try {
					IJavaElement[] children= filter(c.getChildren());
					return (children != null && children.length > 0);
				} catch (JavaModelException x) {
					x.printStackTrace();
				}
			}
			return false;
		}

		public void dispose() {
			if (fListener != null) {
				JavaCore.removeElementChangedListener(fListener);
				fListener= null;
			}
		}

		/*
		 * @see IContentProvider#inputChanged(Viewer, Object, Object)
		 */
		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
			boolean isCU= (newInput instanceof ICompilationUnit);

			if (isCU && fListener == null) {
				fListener= new ElementChangedListener();
				JavaCore.addElementChangedListener(fListener);
			} else if (!isCU && fListener != null) {
				JavaCore.removeElementChangedListener(fListener);
				fListener= null;
			}
		}
	}
	
	/**
	 * The tree viewer used for displaying the outline.
	 *
	 * @see TreeViewer
	 */
	protected class JetOutlineViewer extends TreeViewer {

		public JetOutlineViewer(Tree tree) {
			super(tree);
			setAutoExpandLevel(ALL_LEVELS);
			setUseHashlookup(true);
		}

		/**
		 * Investigates the given element change event and if affected
		 * incrementally updates the Java outline.
		 *
		 * @param delta the Java element delta used to reconcile the Java outline
		 */
		public void reconcile(IJavaElementDelta delta) {
			refresh(true);
		}

		/*
		 * @see TreeViewer#internalExpandToLevel
		 */
		protected void internalExpandToLevel(Widget node, int level) {
			if (node instanceof Item) {
				Item i= (Item) node;
				if (i.getData() instanceof IJavaElement) {
					IJavaElement je= (IJavaElement) i.getData();
					if (je.getElementType() == IJavaElement.IMPORT_CONTAINER || isInnerType(je)) {
						setExpanded(i, false);
				return;
					}
				}
			}
			super.internalExpandToLevel(node, level);
		}
		
		/**
		 * Checks whether a given Java element is an inner type.
		 *
		 * @param element the java element
		 * @return <code>true</code> iff the given element is an inner type
		 */
		private boolean isInnerType(IJavaElement element) {

			if (element != null && element.getElementType() == IJavaElement.TYPE) {
				IType type= (IType)element;
				try {
					return type.isMember();
				} catch (JavaModelException e) {
					IJavaElement parent= type.getParent();
					if (parent != null) {
						int parentElementType= parent.getElementType();
						return (parentElementType != IJavaElement.COMPILATION_UNIT && parentElementType != IJavaElement.CLASS_FILE);
					}
				}
			}

			return false;
		}

		/*
		 * @see org.eclipse.jface.viewers.AbstractTreeViewer#isExpandable(java.lang.Object)
		 */
		public boolean isExpandable(Object element) {
			if (hasFilters()) {
				return getFilteredChildren(element).length > 0;
			}
			return super.isExpandable(element);
		}

		/*
		 * @see ContentViewer#handleLabelProviderChanged(LabelProviderChangedEvent)
		 */
		protected void handleLabelProviderChanged(LabelProviderChangedEvent event) {
			Object input= getInput();
			if (event instanceof ProblemsLabelChangedEvent) {
				ProblemsLabelChangedEvent e= (ProblemsLabelChangedEvent) event;
				if (e.isMarkerChange() && input instanceof ICompilationUnit) {
					return; // marker changes can be ignored
				}
			}
			// look if the underlying resource changed
			Object[] changed= event.getElements();
			if (changed != null) {
				IResource resource= getUnderlyingResource();
				if (resource != null) {
					for (int i= 0; i < changed.length; i++) {
						if (changed[i] != null && changed[i].equals(resource)) {
							// change event to a full refresh
							event= new LabelProviderChangedEvent((IBaseLabelProvider) event.getSource());
							break;
						}
					}
				}
			}
			super.handleLabelProviderChanged(event);
		}

		private IResource getUnderlyingResource() {
			Object input= getInput();
			if (input instanceof ICompilationUnit) {
				ICompilationUnit cu= (ICompilationUnit) input;
				cu= cu.getPrimary();
				return cu.getResource();
			} else if (input instanceof IClassFile) {
				return ((IClassFile) input).getResource();
			}
			return null;
		}

	}
	
	/**
	 * Empty selection provider.
	 *
	 * @since 3.2
	 */
	private static final class EmptySelectionProvider implements ISelectionProvider {
		public void addSelectionChangedListener(ISelectionChangedListener listener) {
		}
		public ISelection getSelection() {
			return StructuredSelection.EMPTY;
		}
		public void removeSelectionChangedListener(ISelectionChangedListener listener) {
		}
		public void setSelection(ISelection selection) {
		}
	}
	
	private class CompositeActionGroup extends ActionGroup {

		private ActionGroup[] fGroups;

		public CompositeActionGroup() {
		}

		public CompositeActionGroup(ActionGroup[] groups) {
			setGroups(groups);
		}

		protected void setGroups(ActionGroup[] groups) {
			Assert.isTrue(fGroups == null);
			Assert.isNotNull(groups);
			fGroups= groups;
		}

		public void addGroup(ActionGroup group) {
			if (fGroups == null) {
				fGroups= new ActionGroup[] { group };
			} else {
				ActionGroup[] newGroups= new ActionGroup[fGroups.length + 1];
				System.arraycopy(fGroups, 0, newGroups, 0, fGroups.length);
				newGroups[fGroups.length]= group;
				fGroups= newGroups;
			}
		}

		public void dispose() {
			super.dispose();
			if (fGroups == null)
				return;
			for (int i= 0; i < fGroups.length; i++) {
				fGroups[i].dispose();
			}
		}

		public void fillActionBars(IActionBars actionBars) {
			super.fillActionBars(actionBars);
			if (fGroups == null)
				return;
			for (int i= 0; i < fGroups.length; i++) {
				fGroups[i].fillActionBars(actionBars);
			}
		}

		public void fillContextMenu(IMenuManager menu) {
			super.fillContextMenu(menu);
			if (fGroups == null)
				return;
			for (int i= 0; i < fGroups.length; i++) {
				fGroups[i].fillContextMenu(menu);
			}
		}

		public void setContext(ActionContext context) {
			super.setContext(context);
			if (fGroups == null)
				return;
			for (int i= 0; i < fGroups.length; i++) {
				fGroups[i].setContext(context);
			}
		}

		public void updateActionBars() {
			super.updateActionBars();
			if (fGroups == null)
				return;
			for (int i= 0; i < fGroups.length; i++) {
				fGroups[i].updateActionBars();
			}
		}
	}
	
	private String fContextMenuID = "#CompilationUnitOutlinerContext";
	
	/** A flag to show contents of top level type only */
	private boolean fTopLevelTypeOnly;
	
	private IJavaElement fInput;
	private JetOutlineViewer fOutlineViewer;
	private ListenerList fSelectionChangedListeners= new ListenerList(ListenerList.IDENTITY);
	private ListenerList fPostSelectionChangedListeners= new ListenerList(ListenerList.IDENTITY);
	
	private CompositeActionGroup fActionGroups;
	
	private Menu fMenu;

	public JetOutlinePage(ITextEditor part) {
		IEditorInput input = part.getEditorInput();
		if (input instanceof IFileEditorInput) {
			System.out.println("FILE INPUT");
			IFileEditorInput fileInput = (IFileEditorInput) input;
			IFile file = fileInput.getFile();
			ICompilationUnit iCompUnit = JavaCore.createCompilationUnitFrom(file);
			if (iCompUnit != null) {
				System.out.println("Valid comp unit");
				setInput(iCompUnit);
				return;
			}
		}
		throw new RuntimeException("invalid part for outline view");
	}
	
	public void setInput(IJavaElement inputElement) {
		fInput= inputElement;
		if (fOutlineViewer != null) {
			fOutlineViewer.setInput(fInput);
			updateSelectionProvider(getSite());
		}
//		if (fCategoryFilterActionGroup != null)
//			fCategoryFilterActionGroup.setInput(new IJavaElement[] {fInput});
	}
	
	private void updateSelectionProvider(IPageSite site) {
		ISelectionProvider provider= fOutlineViewer;
		if (fInput != null) {
			ICompilationUnit cu= (ICompilationUnit)fInput.getAncestor(IJavaElement.COMPILATION_UNIT);
			if (cu != null && !(cu.getOwner() == null))
				provider= new EmptySelectionProvider();
		}
		site.setSelectionProvider(provider);
	}

	/*
	 * @see IPage#createControl
	 */
	@Override
	public void createControl(Composite parent) {

		Tree tree= new Tree(parent, SWT.MULTI);
		
		fOutlineViewer= new JetOutlineViewer(tree);
//		initDragAndDrop();
		fOutlineViewer.setContentProvider(new ChildrenProvider());
		
		AppearanceAwareLabelProvider lprovider = new AppearanceAwareLabelProvider(
				AppearanceAwareLabelProvider.DEFAULT_TEXTFLAGS
						| JavaElementLabels.F_APP_TYPE_SIGNATURE
						| JavaElementLabels.ALL_CATEGORY,
				AppearanceAwareLabelProvider.DEFAULT_IMAGEFLAGS);
		fOutlineViewer.setLabelProvider(new DecoratingJavaLabelProvider(lprovider));


		Object[] listeners= fSelectionChangedListeners.getListeners();
		for (int i= 0; i < listeners.length; i++) {
			fSelectionChangedListeners.remove(listeners[i]);
			fOutlineViewer.addSelectionChangedListener((ISelectionChangedListener) listeners[i]);
		}

		listeners= fPostSelectionChangedListeners.getListeners();
		for (int i= 0; i < listeners.length; i++) {
			fPostSelectionChangedListeners.remove(listeners[i]);
			fOutlineViewer.addPostSelectionChangedListener((ISelectionChangedListener) listeners[i]);
		}

		MenuManager manager= new MenuManager(fContextMenuID, fContextMenuID);
		manager.setRemoveAllWhenShown(true);
		manager.addMenuListener(new IMenuListener() {
			public void menuAboutToShow(IMenuManager m) {
				contextMenuAboutToShow(m);
			}
		});
		fMenu= manager.createContextMenu(tree);
		tree.setMenu(fMenu);

		IPageSite site= getSite();
		site.registerContextMenu(JavaUI.ID_PLUGIN + ".outline", manager, fOutlineViewer); //$NON-NLS-1$

		updateSelectionProvider(site);

		// we must create the groups after we have set the selection provider to the site
		fActionGroups= new CompositeActionGroup(new ActionGroup[] {
				new OpenViewActionGroup(this),
				new CCPActionGroup(this),
				new GenerateActionGroup(this),
				new RefactorActionGroup(this),
				new JavaSearchActionGroup(this)});

		// register global actions
//		IActionBars actionBars= site.getActionBars();
//		actionBars.setGlobalActionHandler(ITextEditorActionConstants.UNDO, fEditor.getAction(ITextEditorActionConstants.UNDO));
//		actionBars.setGlobalActionHandler(ITextEditorActionConstants.REDO, fEditor.getAction(ITextEditorActionConstants.REDO));

//		IAction action= fEditor.getAction(ITextEditorActionConstants.NEXT);
//		actionBars.setGlobalActionHandler(ITextEditorActionDefinitionIds.GOTO_NEXT_ANNOTATION, action);
//		actionBars.setGlobalActionHandler(ITextEditorActionConstants.NEXT, action);
//		action= fEditor.getAction(ITextEditorActionConstants.PREVIOUS);
//		actionBars.setGlobalActionHandler(ITextEditorActionDefinitionIds.GOTO_PREVIOUS_ANNOTATION, action);
//		actionBars.setGlobalActionHandler(ITextEditorActionConstants.PREVIOUS, action);

//		actionBars.setGlobalActionHandler(ITextEditorActionDefinitionIds.TOGGLE_SHOW_SELECTED_ELEMENT_ONLY, fTogglePresentation);

//		fActionGroups.fillActionBars(actionBars);
//
//		IStatusLineManager statusLineManager= actionBars.getStatusLineManager();
//		if (statusLineManager != null) {
//			StatusBarUpdater updater= new StatusBarUpdater(statusLineManager);
//			fOutlineViewer.addPostSelectionChangedListener(updater);
//		}
		// Custom filter group
//		fCustomFiltersActionGroup= new CustomFiltersActionGroup("gov.nasa.jpf.jet.views.JetOutlinePage", fOutlineViewer); //$NON-NLS-1$

//		fOpenAndLinkWithEditorHelper= new OpenAndLinkWithEditorHelper(fOutlineViewer) {
//
//			protected void activate(ISelection selection) {
//				fEditor.doSelectionChanged(selection);
//				getSite().getPage().activate(fEditor);
//			}
//
//			protected void linkToEditor(ISelection selection) {
//				fEditor.doSelectionChanged(selection);
//
//			}
//
//			protected void open(ISelection selection, boolean activate) {
//				fEditor.doSelectionChanged(selection);
//				if (activate)
//					getSite().getPage().activate(fEditor);
//			}
//
//		};

//		registerToolbarActions(actionBars);

		IHandlerService handlerService= (IHandlerService)site.getService(IHandlerService.class);
//		handlerService.activateHandler(IWorkbenchCommandConstants.NAVIGATE_TOGGLE_LINK_WITH_EDITOR, new ActionHandler(fToggleLinkingAction));


		fOutlineViewer.setInput(fInput);
	}
	
	protected void contextMenuAboutToShow(IMenuManager menu) {

		createStandardGroups(menu);

		IStructuredSelection selection= (IStructuredSelection)getSelection();
		fActionGroups.setContext(new ActionContext(selection));
		fActionGroups.fillContextMenu(menu);
	}
	
	/**
	 * Creates the Java plug-in's standard groups for view context menus.
	 *
	 * @param menu the menu manager to be populated
	 */
	public void createStandardGroups(IMenuManager menu) {
		if (!menu.isEmpty())
			return;

		menu.add(new Separator(IContextMenuConstants.GROUP_NEW));
		menu.add(new GroupMarker(IContextMenuConstants.GROUP_GOTO));
		menu.add(new Separator(IContextMenuConstants.GROUP_OPEN));
		menu.add(new GroupMarker(IContextMenuConstants.GROUP_SHOW));
		menu.add(new Separator(ICommonMenuConstants.GROUP_EDIT));
		menu.add(new Separator(IContextMenuConstants.GROUP_REORGANIZE));
		menu.add(new Separator(IContextMenuConstants.GROUP_GENERATE));
		menu.add(new Separator(IContextMenuConstants.GROUP_SEARCH));
		menu.add(new Separator(IContextMenuConstants.GROUP_BUILD));
		menu.add(new Separator(IContextMenuConstants.GROUP_ADDITIONS));
		menu.add(new Separator(IContextMenuConstants.GROUP_VIEWER_SETUP));
		menu.add(new Separator(IContextMenuConstants.GROUP_PROPERTIES));
	}

	
	@Override
	public Control getControl() {
		if (fOutlineViewer != null)
			return fOutlineViewer.getControl();
		return null;
	}

	/*
	 * @see Page#setFocus()
	 */
	@Override
	public void setFocus() {
		if (fOutlineViewer != null)
			fOutlineViewer.getControl().setFocus();
	}
	
	/*
	 * @see ISelectionProvider#addSelectionChangedListener(ISelectionChangedListener)
	 */
	@Override
	public void addSelectionChangedListener(ISelectionChangedListener listener) {
		if (fOutlineViewer != null)
			fOutlineViewer.addSelectionChangedListener(listener);
		else
			fSelectionChangedListeners.add(listener);
	}

	/*
	 * @see ISelectionProvider#getSelection()
	 */
	@Override
	public ISelection getSelection() {
		if (fOutlineViewer == null)
			return StructuredSelection.EMPTY;
		return fOutlineViewer.getSelection();
	}

	/*
	 * @see ISelectionProvider#removeSelectionChangedListener(ISelectionChangedListener)
	 */
	@Override
	public void removeSelectionChangedListener(ISelectionChangedListener listener) {
		if (fOutlineViewer != null)
			fOutlineViewer.removeSelectionChangedListener(listener);
		else
			fSelectionChangedListeners.remove(listener);
	}

	/*
	 * @see ISelectionProvider#setSelection(ISelection)
	 */
	@Override
	public void setSelection(ISelection selection) {
		if (fOutlineViewer != null)
			fOutlineViewer.setSelection(selection);
	}

	
	/*
	 * @see org.eclipse.jface.text.IPostSelectionProvider#addPostSelectionChangedListener(org.eclipse.jface.viewers.ISelectionChangedListener)
	 */
	@Override
	public void addPostSelectionChangedListener(ISelectionChangedListener listener) {
		if (fOutlineViewer != null)
			fOutlineViewer.addPostSelectionChangedListener(listener);
		else
			fPostSelectionChangedListeners.add(listener);
	}
	

	/*
	 * @see org.eclipse.jface.text.IPostSelectionProvider#removePostSelectionChangedListener(org.eclipse.jface.viewers.ISelectionChangedListener)
	 */
	@Override
	public void removePostSelectionChangedListener(ISelectionChangedListener listener) {
		if (fOutlineViewer != null)
			fOutlineViewer.removePostSelectionChangedListener(listener);
		else
			fPostSelectionChangedListeners.remove(listener);
	}

	/*
	 * @see org.eclipse.ui.part.Page#init(org.eclipse.ui.part.IPageSite)
	 */
	public void init(IPageSite pageSite) {
		super.init(pageSite);
	}
}
